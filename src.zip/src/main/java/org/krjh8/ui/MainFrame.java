package org.krjh8.ui;

import org.krjh8.ui.dialogs.RefactorImportsDialog;
import org.krjh8.ui.dialogs.RemoveCommentsDialog;
import org.krjh8.ui.AIPanelManager;
import org.krjh8.file.FileManager;
import org.krjh8.maven.MavenExecutor;
import org.krjh8.project.ProjectManager;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.List;
import java.util.logging.Logger;

import com.formdev.flatlaf.FlatDarculaLaf;

public class MainFrame extends JFrame {
    private static final Logger LOGGER = Logger.getLogger(MainFrame.class.getName());
    
    private ProjectManager projectManager;
    private EditorPanel editorPanel;
    private ConsolePanel consolePanel;
    private AIPanelManager aiPanel;
    private FileExplorerPanel fileExplorerPanel;
    private IDEMenuBar menuBar;
    private ToolBar toolBar;
    private JSplitPane mainSplit;
    private JSplitPane rightSplit;
    private JSplitPane rightSplitWithAI;
    private JLabel projectStatusLabel;
    private JLabel editorStatusLabel;
    private JPanel mainContentPanel;

    private boolean aiPanelVisible = false;

    public MainFrame() {
        applyDarkTheme();
        setTitle("☕ Java Plugin IDE v2.0 - Dark Mode");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 800);
        setLocationRelativeTo(null);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        projectManager = new ProjectManager();
        setupUI();
        setupListeners();
        setVisible(true);
    }

    private void applyDarkTheme() {
        try {
            FlatDarculaLaf.setup();
            UIManager.put("TextComponent.arc", 5);
            UIManager.put("Button.arc", 5);
            UIManager.put("Component.arc", 5);
            UIManager.put("Panel.background", new Color(43, 43, 43));
            UIManager.put("SplitPane.background", new Color(43, 43, 43));
        } catch (Exception e) {
            LOGGER.warning("Error aplicando tema oscuro: " + e.getMessage());
        }
    }

    private void setupUI() {
        menuBar = new IDEMenuBar();
        setJMenuBar(menuBar);

        toolBar = new ToolBar();
        toolBar.setFloatable(false);
        add(toolBar, BorderLayout.NORTH);

        JPanel statusPanel = new JPanel(new BorderLayout());
        statusPanel.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, Color.GRAY));
        
        projectStatusLabel = new JLabel("🔴 Sin proyecto abierto");
        projectStatusLabel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        statusPanel.add(projectStatusLabel, BorderLayout.WEST);

        editorStatusLabel = new JLabel("Listo");
        editorStatusLabel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        editorStatusLabel.setHorizontalAlignment(JLabel.RIGHT);
        statusPanel.add(editorStatusLabel, BorderLayout.EAST);
        add(statusPanel, BorderLayout.SOUTH);

        mainContentPanel = new JPanel(new BorderLayout());
        editorPanel = new EditorPanel();
        consolePanel = new ConsolePanel();
        aiPanel = new AIPanelManager(null);

        rightSplit = new JSplitPane(JSplitPane.VERTICAL_SPLIT, editorPanel, consolePanel);
        rightSplit.setDividerLocation(500);
        rightSplit.setResizeWeight(0.7);
        rightSplit.setDividerSize(8);

        mainSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, createEmptyFileExplorerPlaceholder(), rightSplit);
        mainSplit.setDividerLocation(250);
        mainSplit.setResizeWeight(0.2);
        mainSplit.setDividerSize(8);
        mainSplit.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, Color.DARK_GRAY));

        mainContentPanel.add(mainSplit, BorderLayout.CENTER);
        add(mainContentPanel, BorderLayout.CENTER);
    }

    private JPanel createEmptyFileExplorerPlaceholder() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, Color.DARK_GRAY));
        JLabel label = new JLabel(
            "<html><center><br><br><br><br>" +
            "<font size='5' color='#5599FF'><b>📁 Explorador de Archivos</b></font><br><br>" +
            "<font color='#AAAAAA'>Abre un proyecto para ver sus archivos</font><br><br>" +
            "<font color='#CCCCCC'><b>Archivo → Abrir Proyecto</b></font>" +
            "</center></html>"
        );
        label.setHorizontalAlignment(JLabel.CENTER);
        panel.add(label, BorderLayout.CENTER);
        return panel;
    }

    private void setupListeners() {
        // Menú Archivo y Proyecto
        menuBar.addNewProjectListener(e -> newProject());
        menuBar.addOpenProjectListener(e -> openProject());
        menuBar.addExitListener(e -> exitApplication());

        // Menú Construir
        menuBar.addCompileListener(e -> compile());
        menuBar.addBuildJarListener(e -> buildJar());
        menuBar.addRunTestsListener(e -> runTests());

        // Menú Ver (Nuevas ubicaciones)
        menuBar.addRefactorImportsListener(e -> refactorImports());
        menuBar.addRemoveCommentsListener(e -> removeComments());

        // Menú IA
        menuBar.addAIListener(e -> toggleAIPanel());

        // Barra de herramientas (Solo lo básico)
        toolBar.addNewProjectListener(e -> newProject());
        toolBar.addOpenProjectListener(e -> openProject());
        toolBar.addSaveListener(e -> saveFile());
    }

    private void refactorImports() {
        if (!validarProyectoAbierto()) return;
        updateEditorStatus("Abriendo refactor de imports...");
        RefactorImportsDialog dialog = new RefactorImportsDialog(this, projectManager.getCurrentProject(),
            new RefactorImportsDialog.ConsoleAppender() {
                @Override public void append(String text) { consolePanel.append(text); }
                @Override public void appendLines(List<String> lines) { consolePanel.appendLines(lines); }
            }
        );
        dialog.setVisible(true);
        updateEditorStatus("Listo");
    }

    private void removeComments() {
        if (!validarProyectoAbierto()) return;
        updateEditorStatus("Abriendo limpiador de comentarios...");
        RemoveCommentsDialog dialog = new RemoveCommentsDialog(this, projectManager.getCurrentProject(),
            new RemoveCommentsDialog.ConsoleAppender() {
                @Override public void append(String text) { consolePanel.append(text); }
                @Override public void appendLines(List<String> lines) { consolePanel.appendLines(lines); }
            }
        );
        dialog.setVisible(true);
        updateEditorStatus("Listo");
    }

    private void toggleAIPanel() {
        if (!aiPanelVisible) {
            if (aiPanel.getParent() == null) {
                rightSplitWithAI = new JSplitPane(JSplitPane.VERTICAL_SPLIT, rightSplit, aiPanel);
                rightSplitWithAI.setDividerLocation(600);
                rightSplitWithAI.setResizeWeight(0.75);
                rightSplitWithAI.setDividerSize(8);
                mainSplit.setRightComponent(rightSplitWithAI);
            }
            aiPanelVisible = true;
            consolePanel.append("✓ Panel de IA abierto");
        } else {
            mainSplit.setRightComponent(rightSplit);
            aiPanelVisible = false;
            consolePanel.append("✓ Panel de IA cerrado");
        }
        mainContentPanel.revalidate();
        mainContentPanel.repaint();
    }
 
    private void newProject() {
        JDialog dialog = new JDialog(this, "Nuevo Proyecto Maven", true);
        dialog.setSize(550, 420);
        dialog.setLocationRelativeTo(this);
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel titleLabel = new JLabel("📦 Crear Nuevo Proyecto Maven");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titleLabel.setForeground(new Color(100, 149, 237)); 
        mainPanel.add(titleLabel, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridLayout(6, 2, 10, 10));
        JButton browseBtn = new JButton("📁 Examinar...");
        JTextField pathField = new JTextField();
        pathField.setEditable(false);
        
        browseBtn.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            if (chooser.showOpenDialog(dialog) == JFileChooser.APPROVE_OPTION) pathField.setText(chooser.getSelectedFile().getAbsolutePath());
        });

        JPanel pathPanel = new JPanel(new BorderLayout(5, 0));
        pathPanel.add(pathField, BorderLayout.CENTER);
        pathPanel.add(browseBtn, BorderLayout.EAST);

        formPanel.add(new JLabel("📁 Ruta del proyecto:"));
        formPanel.add(pathPanel);
        formPanel.add(new JLabel("📦 Group ID:"));
        formPanel.add(new JTextField("com.example"));
        formPanel.add(new JLabel("🏷️ Artifact ID:"));
        formPanel.add(new JTextField("myplugin"));
        formPanel.add(new JLabel("📌 Versión:"));
        formPanel.add(new JTextField("1.0.0"));

        JTextArea descriptionArea = new JTextArea("Descripción de mi plugin", 3, 20);
        descriptionArea.setLineWrap(true);
        descriptionArea.setWrapStyleWord(true);
        formPanel.add(new JLabel("📝 Descripción:"));
        formPanel.add(new JScrollPane(descriptionArea));

        mainPanel.add(formPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        JButton createBtn = new JButton("✓ Crear Proyecto");
        JButton cancelBtn = new JButton("✕ Cancelar");

        createBtn.addActionListener(e -> {
            String path = pathField.getText().trim();
            String groupId = ((JTextField)formPanel.getComponent(3)).getText().trim();
            String artifactId = ((JTextField)formPanel.getComponent(5)).getText().trim();
            String version = ((JTextField)formPanel.getComponent(7)).getText().trim();

            if (path.isEmpty() || groupId.isEmpty() || artifactId.isEmpty() || version.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "⚠️ Completa todos los campos", "Validación", JOptionPane.WARNING_MESSAGE);
                return;
            }

            updateEditorStatus("Creando proyecto...");
            if (projectManager.createNewProject(path, groupId, artifactId, version)) {
                openProjectInternal(path);
                dialog.dispose();
                JOptionPane.showMessageDialog(this, "✓ Proyecto creado exitosamente\n\n" + path, "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(dialog, "✗ Error al crear el proyecto", "Error", JOptionPane.ERROR_MESSAGE);
                updateEditorStatus("Error al crear proyecto");
            }
        });

        cancelBtn.addActionListener(e -> dialog.dispose());
        buttonPanel.add(createBtn);
        buttonPanel.add(cancelBtn);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        dialog.getContentPane().add(mainPanel);
        dialog.setVisible(true);
    }

    private void openProject() {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        chooser.setDialogTitle("Abrir Proyecto Maven");
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) openProjectInternal(chooser.getSelectedFile().getAbsolutePath());
    }

    private void openProjectInternal(String projectPath) {
        updateEditorStatus("Abriendo proyecto...");
        if (projectManager.openProject(projectPath)) {
            consolePanel.clear();
            consolePanel.append("═══════════════════════════════════════════════════════════");
            consolePanel.append("✓ Proyecto abierto exitosamente");
            consolePanel.append("📂 Ubicación: " + projectPath);
            consolePanel.append("═══════════════════════════════════════════════════════════");
            
            projectStatusLabel.setText("🟢 Proyecto: " + projectManager.getProjectName());
            projectStatusLabel.setForeground(new Color(100, 200, 100));
            updateEditorStatus("Proyecto abierto");

            fileExplorerPanel = new FileExplorerPanel(projectManager.getCurrentProject(), this);
            fileExplorerPanel.addFileSelectedListener(file -> {
                if (file.isFile()) {
                    editorPanel.openFile(file);
                    consolePanel.append("📄 Archivo abierto: " + file.getName() + " (" + getFileType(file.getName()) + ")");
                    updateEditorStatus("Editando: " + file.getName());
                }
            });

            mainSplit.setLeftComponent(fileExplorerPanel);
            mainSplit.setDividerLocation(250);
            aiPanel.setProjectRoot(projectManager.getCurrentProject());
        } else {
            JOptionPane.showMessageDialog(this, "✗ No es un proyecto Maven válido\n(Debe contener un archivo pom.xml)", "Error", JOptionPane.ERROR_MESSAGE);
            projectStatusLabel.setText("🔴 Error al abrir proyecto");
            projectStatusLabel.setForeground(Color.RED);
            updateEditorStatus("Error");
        }
    }

        private void compile() {
        if (!validarProyectoAbierto()) return;
        consolePanel.clear();
        consolePanel.append("═══════════════════════════════════════════════════════════");
        consolePanel.append("🔨 Compilando proyecto...");
        consolePanel.append("═══════════════════════════════════════════════════════════");
        updateEditorStatus("Compilando...");

        new Thread(() -> {
            MavenExecutor executor = new MavenExecutor(projectManager.getCurrentProject());

            if (executor.compile()) {
                SwingUtilities.invokeLater(() -> {
                    consolePanel.append("\n✓ Compilación exitosa\n");
                    // ⭐ UNIR AMBOS FLUJOS PARA VER TODO
                    mostrarTodosLosLogs(executor);
                    consolePanel.append("═══════════════════════════════════════════════════════════");
                    updateEditorStatus("Compilación exitosa");
                    JOptionPane.showMessageDialog(this, "✓ Compilación exitosa", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                });
            } else {
                SwingUtilities.invokeLater(() -> {
                    consolePanel.append("\n✗ Error en compilación\n");
                    mostrarTodosLosLogs(executor);
                    consolePanel.append("═══════════════════════════════════════════════════════════");
                    updateEditorStatus("Error en compilación");
                });
            }
        }).start();
    }

    private void buildJar() {
        if (!validarProyectoAbierto()) return;
        consolePanel.clear();
        consolePanel.append("═══════════════════════════════════════════════════════════");
        consolePanel.append("📦 Construyendo JAR...");
        consolePanel.append("═══════════════════════════════════════════════════════════");
        updateEditorStatus("Construyendo JAR...");

        new Thread(() -> {
            MavenExecutor executor = new MavenExecutor(projectManager.getCurrentProject());

            if (executor.buildJar()) {
                SwingUtilities.invokeLater(() -> {
                    consolePanel.append("\n✓ JAR construido exitosamente\n");
                    mostrarTodosLosLogs(executor);
                    
                    String jarPath = projectManager.getCurrentProject().getAbsolutePath() + File.separator + "target";
                    consolePanel.append("\n📍 Ubicación del JAR: " + jarPath);
                    File targetDir = new File(jarPath);
                    if (targetDir.exists()) {
                        File[] jarFiles = targetDir.listFiles((dir, name) -> name.endsWith(".jar"));
                        if (jarFiles != null) for (File jar : jarFiles) consolePanel.append("   📌 " + jar.getName() + " (" + (jar.length() / 1024) + " KB)");
                    }
                    consolePanel.append("═══════════════════════════════════════════════════════════");
                    updateEditorStatus("Build JAR completado");
                    JOptionPane.showMessageDialog(this, "✓ JAR construido exitosamente\n\n" + jarPath, "Éxito", JOptionPane.INFORMATION_MESSAGE);
                });
            } else {
                SwingUtilities.invokeLater(() -> {
                    consolePanel.append("\n✗ Error construyendo JAR\n");
                    mostrarTodosLosLogs(executor);
                    consolePanel.append("═══════════════════════════════════════════════════════════");
                    updateEditorStatus("Error en build JAR");
                });
            }
        }).start();
    }

    private void runTests() {
        if (!validarProyectoAbierto()) return;
        consolePanel.clear();
        consolePanel.append("═══════════════════════════════════════════════════════════");
        consolePanel.append("🧪 Ejecutando tests...");
        consolePanel.append("═══════════════════════════════════════════════════════════");
        updateEditorStatus("Ejecutando tests...");

        new Thread(() -> {
            MavenExecutor executor = new MavenExecutor(projectManager.getCurrentProject());

            if (executor.runTests()) {
                SwingUtilities.invokeLater(() -> {
                    consolePanel.append("\n✓ Tests ejecutados exitosamente\n");
                    mostrarTodosLosLogs(executor);
                    consolePanel.append("═══════════════════════════════════════════════════════════");
                    updateEditorStatus("Tests completados");
                    JOptionPane.showMessageDialog(this, "✓ Tests ejecutados exitosamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                });
            } else {
                SwingUtilities.invokeLater(() -> {
                    consolePanel.append("\n✗ Error ejecutando tests\n");
                    mostrarTodosLosLogs(executor);
                    consolePanel.append("═══════════════════════════════════════════════════════════");
                    updateEditorStatus("Error en tests");
                });
            }
        }).start();
    }

    // ⭐ NUEVO MÉTODO AUXILIAR PARA JUNTAR LOS LOGS
    private void mostrarTodosLosLogs(MavenExecutor executor) {
        // Intentamos sacar lo que haya en ambos flujos (Output y Errors)
        // Porque Maven manda los [INFO] casi siempre al flujo de Errores
        try {
            if (executor.getOutput() != null && !executor.getOutput().isEmpty()) {
                consolePanel.appendLines(executor.getOutput());
            }
        } catch (Exception e) {}

        try {
            if (executor.getErrors() != null && !executor.getErrors().isEmpty()) {
                consolePanel.appendLines(executor.getErrors());
            }
        } catch (Exception e) {}
    }
    private void saveFile() {
        if (editorPanel.getCurrentFile() == null) {
            JOptionPane.showMessageDialog(this, "⚠️ No hay archivo abierto", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (editorPanel.saveFile()) {
            consolePanel.append("✓ Archivo guardado: " + editorPanel.getCurrentFile().getName());
            updateEditorStatus("Guardado: " + editorPanel.getCurrentFile().getName());
        } else {
            JOptionPane.showMessageDialog(this, "✗ Error al guardar el archivo", "Error", JOptionPane.ERROR_MESSAGE);
            updateEditorStatus("Error al guardar");
        }
    }

    private boolean validarProyectoAbierto() {
        if (projectManager.getCurrentProject() == null) {
            JOptionPane.showMessageDialog(this, "⚠️ Por favor abra un proyecto primero", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    private String getFileType(String fileName) {
        String n = fileName.toLowerCase();
        if (n.endsWith(".java")) return "Java Source";
        if (n.endsWith(".xml") || n.endsWith(".pom")) return "XML";
        if (n.endsWith(".properties")) return "Properties";
        if (n.endsWith(".json")) return "JSON";
        if (n.endsWith(".yml") || n.endsWith(".yaml")) return "YAML";
        return "Archivo";
    }

    private void updateEditorStatus(String status) { SwingUtilities.invokeLater(() -> editorStatusLabel.setText(status)); }

    private void exitApplication() {
        if (editorPanel.isModified()) {
            if (JOptionPane.showConfirmDialog(this, "⚠️ Hay cambios sin guardar.\n¿Deseas salir?", "Confirmar salida", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) != JOptionPane.YES_OPTION) return;
        }
        if (aiPanel != null) aiPanel.dispose();
        System.exit(0);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}