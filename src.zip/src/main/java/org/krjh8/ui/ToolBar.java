package org.krjh8.ui;

import javax.swing.*;
import java.awt.event.ActionListener;

public class ToolBar extends JToolBar {
    private JButton newProjectBtn;
    private JButton openProjectBtn;
    private JButton saveBtn;

    public ToolBar() {
        setFloatable(false);
        
        newProjectBtn = addButton("Nuevo Proyecto", "new");
        addSeparator();
        
        openProjectBtn = addButton("Abrir Proyecto", "open");
        addSeparator();
        
        saveBtn = addButton("Guardar", "save");
    }

    private JButton addButton(String text, String actionCommand) {
        JButton button = new JButton(text);
        button.setActionCommand(actionCommand);
        add(button);
        return button;
    }

    public void addNewProjectListener(ActionListener listener) {
        newProjectBtn.addActionListener(listener);
    }

    public void addOpenProjectListener(ActionListener listener) {
        openProjectBtn.addActionListener(listener);
    }

    public void addSaveListener(ActionListener listener) {
        saveBtn.addActionListener(listener);
    }
}