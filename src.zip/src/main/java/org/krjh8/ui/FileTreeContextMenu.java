package org.krjh8.ui;

import org.krjh8.file.FileManager;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import java.io.File;

public class FileTreeContextMenu extends JPopupMenu {
    private FileExplorerPanel explorerPanel;
    private JMenuItem createFileItem;
    private JMenuItem createFolderItem;
    private JMenuItem deleteItem;
    private JMenuItem renameItem;
    private JMenuItem refreshItem;
    private JMenuItem newClassItem;
    private JMenuItem newPluginItem;

    public FileTreeContextMenu(FileExplorerPanel explorerPanel) {
        this.explorerPanel = explorerPanel;
        setupMenuItems();
    }

    private void setupMenuItems() {
        createFileItem = new JMenuItem("📄 Crear Archivo");
        createFileItem.addActionListener(e -> createNewFile());
        add(createFileItem);

        createFolderItem = new JMenuItem("📁 Crear Carpeta");
        createFolderItem.addActionListener(e -> createNewFolder());
        add(createFolderItem);

        addSeparator();

        newClassItem = new JMenuItem("☕ Nueva Clase Java");
        newClassItem.addActionListener(e -> createNewJavaClass());
        add(newClassItem);

        newPluginItem = new JMenuItem("🔌 Nuevo Plugin");
        newPluginItem.addActionListener(e -> createNewPlugin());
        add(newPluginItem);

        addSeparator();

        renameItem = new JMenuItem("✏️ Renombrar");
        renameItem.addActionListener(e -> renameFile());
        add(renameItem);

        deleteItem = new JMenuItem("🗑️ Eliminar");
        deleteItem.setForeground(java.awt.Color.RED);
        deleteItem.addActionListener(e -> deleteFile());
        add(deleteItem);

        addSeparator();

        refreshItem = new JMenuItem("🔄 Refrescar");
        refreshItem.addActionListener(e -> refreshNodeManual());
        add(refreshItem);
    }

    public void show(JTree tree, int x, int y, File selectedFile, DefaultMutableTreeNode node) {
        boolean isFolder = selectedFile.isDirectory();

        createFileItem.setEnabled(isFolder);
        createFolderItem.setEnabled(isFolder);
        newClassItem.setEnabled(isFolder);
        newPluginItem.setEnabled(isFolder);
        deleteItem.setEnabled(selectedFile != null);
        renameItem.setEnabled(selectedFile != null);

        super.show(tree, x, y);
    }

    private void createNewFile() {
        File selectedFile = explorerPanel.getSelectedFile();
        if (selectedFile == null || !selectedFile.isDirectory()) return;

        String fileName = JOptionPane.showInputDialog(this, "Nombre del archivo:", "archivo.txt");

        if (fileName != null && !fileName.trim().isEmpty()) {
            File newFile = new File(selectedFile, fileName.trim());
            try {
                if (newFile.createNewFile()) {
                    DefaultMutableTreeNode selectedNode =
                        (DefaultMutableTreeNode) explorerPanel.getFileTree()
                        .getLastSelectedPathComponent();
                    if (selectedNode != null) {
                        selectedNode.removeAllChildren();
                        explorerPanel.refreshNode(selectedNode);
                    }
                    JOptionPane.showMessageDialog(this,
                        "✓ Archivo creado: " + fileName, "Éxito", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this,
                        "✗ El archivo ya existe", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                    "✗ Error al crear archivo: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void createNewFolder() {
        File selectedFile = explorerPanel.getSelectedFile();
        if (selectedFile == null || !selectedFile.isDirectory()) return;

        String folderName = JOptionPane.showInputDialog(this, "Nombre de la carpeta:", "nueva_carpeta");

        if (folderName != null && !folderName.trim().isEmpty()) {
            File newFolder = new File(selectedFile, folderName.trim());
            if (newFolder.mkdir()) {
                DefaultMutableTreeNode selectedNode =
                    (DefaultMutableTreeNode) explorerPanel.getFileTree()
                    .getLastSelectedPathComponent();
                if (selectedNode != null) {
                    selectedNode.removeAllChildren();
                    explorerPanel.refreshNode(selectedNode);
                }
                JOptionPane.showMessageDialog(this,
                    "✓ Carpeta creada: " + folderName, "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this,
                    "✗ No se pudo crear la carpeta", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void createNewJavaClass() {
        File selectedFile = explorerPanel.getSelectedFile();
        if (selectedFile == null || !selectedFile.isDirectory()) return;

        JDialog dialog = new JDialog(
            (JFrame) SwingUtilities.getWindowAncestor(this), "Nueva Clase Java", true);
        dialog.setSize(450, 250);
        dialog.setLocationRelativeTo(this);
        dialog.getContentPane().setBackground(new java.awt.Color(245, 245, 245));

        JPanel mainPanel = new JPanel(new java.awt.BorderLayout());
        mainPanel.setBackground(new java.awt.Color(245, 245, 245));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel titleLabel = new JLabel("☕ Nueva Clase Java");
        titleLabel.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 14));
        titleLabel.setForeground(new java.awt.Color(0, 102, 204));
        mainPanel.add(titleLabel, java.awt.BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new java.awt.GridLayout(3, 2, 10, 10));
        formPanel.setBackground(new java.awt.Color(245, 245, 245));

        JTextField packageField = createTextField("com.example");
        JTextField classNameField = createTextField("MiClase");
        JTextArea modifiersArea = new JTextArea("public", 2, 20);
        modifiersArea.setLineWrap(true);
        modifiersArea.setWrapStyleWord(true);

        formPanel.add(createLabel("📦 Paquete:"));
        formPanel.add(packageField);
        formPanel.add(createLabel("📝 Nombre de clase:"));
        formPanel.add(classNameField);
        formPanel.add(createLabel("🔧 Modificadores:"));
        formPanel.add(new JScrollPane(modifiersArea));

        mainPanel.add(formPanel, java.awt.BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 10, 0));
        buttonPanel.setBackground(new java.awt.Color(245, 245, 245));

        JButton createBtn = new JButton("✓ Crear");
        JButton cancelBtn = new JButton("✕ Cancelar");

        createBtn.setBackground(new java.awt.Color(0, 102, 204));
        createBtn.setForeground(java.awt.Color.WHITE);
        createBtn.setFocusPainted(false);

        cancelBtn.setBackground(java.awt.Color.WHITE);
        cancelBtn.setForeground(new java.awt.Color(50, 50, 50));
        cancelBtn.setFocusPainted(false);

        createBtn.addActionListener(e -> {
            String packageName = packageField.getText().trim();
            String className = classNameField.getText().trim();

            if (!packageName.isEmpty() && !className.isEmpty()) {
                File packageDir = new File(selectedFile, packageName.replace(".", File.separator));
                packageDir.mkdirs();

                String classContent = generateClassContent(
                    packageName, className, modifiersArea.getText().trim());

                File classFile = new File(packageDir, className + ".java");
                try {
                    if (FileManager.writeFile(classFile, classContent)) {
                        DefaultMutableTreeNode selectedNode =
                            (DefaultMutableTreeNode) explorerPanel.getFileTree()
                            .getLastSelectedPathComponent();
                        if (selectedNode != null) {
                            selectedNode.removeAllChildren();
                            explorerPanel.refreshNode(selectedNode);
                        }
                        dialog.dispose();
                        JOptionPane.showMessageDialog(this,
                            "✓ Clase creada: " + className, "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this,
                        "✗ Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        cancelBtn.addActionListener(e -> dialog.dispose());

        buttonPanel.add(createBtn);
        buttonPanel.add(cancelBtn);
        mainPanel.add(buttonPanel, java.awt.BorderLayout.SOUTH);

        dialog.add(mainPanel);
        dialog.setVisible(true);
    }

    private void createNewPlugin() {
        File selectedFile = explorerPanel.getSelectedFile();
        if (selectedFile == null || !selectedFile.isDirectory()) return;

        JDialog dialog = new JDialog(
            (JFrame) SwingUtilities.getWindowAncestor(this), "Nuevo Plugin", true);
        dialog.setSize(450, 320);
        dialog.setLocationRelativeTo(this);
        dialog.getContentPane().setBackground(new java.awt.Color(245, 245, 245));

        JPanel mainPanel = new JPanel(new java.awt.BorderLayout());
        mainPanel.setBackground(new java.awt.Color(245, 245, 245));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel titleLabel = new JLabel("🔌 Nuevo Plugin");
        titleLabel.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 14));
        titleLabel.setForeground(new java.awt.Color(0, 102, 204));
        mainPanel.add(titleLabel, java.awt.BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new java.awt.GridLayout(4, 2, 10, 10));
        formPanel.setBackground(new java.awt.Color(245, 245, 245));

        JTextField packageField = createTextField("com.example");
        JTextField pluginNameField = createTextField("MiPlugin");
        JTextArea descriptionArea = new JTextArea("Descripción del plugin", 3, 20);
        descriptionArea.setLineWrap(true);
        descriptionArea.setWrapStyleWord(true);
        descriptionArea.setBackground(java.awt.Color.WHITE);
        descriptionArea.setForeground(new java.awt.Color(50, 50, 50));
        descriptionArea.setBorder(BorderFactory.createLineBorder(new java.awt.Color(200, 200, 200)));
        descriptionArea.setFont(new java.awt.Font("Arial", java.awt.Font.PLAIN, 11));

        formPanel.add(createLabel("📦 Paquete:"));
        formPanel.add(packageField);
        formPanel.add(createLabel("🔌 Nombre del plugin:"));
        formPanel.add(pluginNameField);
        formPanel.add(createLabel("📝 Descripción:"));
        formPanel.add(new JScrollPane(descriptionArea));

        mainPanel.add(formPanel, java.awt.BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 10, 0));
        buttonPanel.setBackground(new java.awt.Color(245, 245, 245));

        JButton createBtn = new JButton("✓ Crear");
        JButton cancelBtn = new JButton("✕ Cancelar");

        createBtn.setBackground(new java.awt.Color(0, 102, 204));
        createBtn.setForeground(java.awt.Color.WHITE);
        createBtn.setFocusPainted(false);

        cancelBtn.setBackground(java.awt.Color.WHITE);
        cancelBtn.setForeground(new java.awt.Color(50, 50, 50));
        cancelBtn.setFocusPainted(false);

        createBtn.addActionListener(e -> {
            String packageName = packageField.getText().trim();
            String pluginName = pluginNameField.getText().trim();

            if (!packageName.isEmpty() && !pluginName.isEmpty()) {
                File packageDir = new File(selectedFile, packageName.replace(".", File.separator));
                packageDir.mkdirs();

                String pluginContent = generatePluginContent(
                    packageName, pluginName, descriptionArea.getText());

                File pluginFile = new File(packageDir, pluginName + ".java");
                try {
                    if (FileManager.writeFile(pluginFile, pluginContent)) {
                        DefaultMutableTreeNode selectedNode =
                            (DefaultMutableTreeNode) explorerPanel.getFileTree()
                            .getLastSelectedPathComponent();
                        if (selectedNode != null) {
                            selectedNode.removeAllChildren();
                            explorerPanel.refreshNode(selectedNode);
                        }
                        dialog.dispose();
                        JOptionPane.showMessageDialog(this,
                            "✓ Plugin creado: " + pluginName, "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this,
                        "✗ Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        cancelBtn.addActionListener(e -> dialog.dispose());

        buttonPanel.add(createBtn);
        buttonPanel.add(cancelBtn);
        mainPanel.add(buttonPanel, java.awt.BorderLayout.SOUTH);

        dialog.add(mainPanel);
        dialog.setVisible(true);
    }

    private void deleteFile() {
        File selectedFile = explorerPanel.getSelectedFile();
        if (selectedFile == null) return;

        int confirm = JOptionPane.showConfirmDialog(
            this,
            "¿Eliminar: " + selectedFile.getName() + "?\n\n" +
            (selectedFile.isDirectory() ? "(Se eliminarán todos los archivos dentro)" : ""),
            "Confirmar eliminación", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            if (deleteFileRecursively(selectedFile)) {
                File parent = selectedFile.getParentFile();
                if (parent != null) {
                    DefaultMutableTreeNode parentNode = findNodeByFile(
                        (DefaultMutableTreeNode) explorerPanel.getFileTree().getModel().getRoot(),
                        parent);
                    if (parentNode != null) {
                        parentNode.removeAllChildren();
                        explorerPanel.refreshNode(parentNode);
                    }
                }
                JOptionPane.showMessageDialog(this,
                    "✓ Eliminado: " + selectedFile.getName(), "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this,
                    "✗ No se pudo eliminar", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void renameFile() {
        File selectedFile = explorerPanel.getSelectedFile();
        if (selectedFile == null) return;

        String newName = JOptionPane.showInputDialog(this, "Nuevo nombre:", selectedFile.getName());

        if (newName != null && !newName.trim().isEmpty() && !newName.equals(selectedFile.getName())) {
            File parent = selectedFile.getParentFile();
            File newFile = new File(parent, newName.trim());

            if (selectedFile.renameTo(newFile)) {
                if (parent != null) {
                    DefaultMutableTreeNode parentNode = findNodeByFile(
                        (DefaultMutableTreeNode) explorerPanel.getFileTree().getModel().getRoot(),
                        parent);
                    if (parentNode != null) {
                        parentNode.removeAllChildren();
                        explorerPanel.refreshNode(parentNode);
                    }
                }
                JOptionPane.showMessageDialog(this,
                    "✓ Renombrado a: " + newName, "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this,
                    "✗ No se pudo renombrar", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void refreshNodeManual() {
        DefaultMutableTreeNode selectedNode =
            (DefaultMutableTreeNode) explorerPanel.getFileTree()
            .getLastSelectedPathComponent();
        if (selectedNode != null) {
            selectedNode.removeAllChildren();
            explorerPanel.refreshNode(selectedNode);
            JOptionPane.showMessageDialog(this,
                "✓ Árbol refrescado", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private boolean deleteFileRecursively(File file) {
        if (file.isDirectory()) {
            File[] files = file.listFiles();
            if (files != null) {
                for (File f : files) {
                    if (!deleteFileRecursively(f)) return false;
                }
            }
        }
        return file.delete();
    }

    private DefaultMutableTreeNode findNodeByFile(DefaultMutableTreeNode node, File targetFile) {
        File current = explorerPanel.getRootDirectory();
        Object[] path = node.getPath();

        for (int i = 1; i < path.length; i++) {
            current = new File(current, path[i].toString());
        }

        if (current.getAbsolutePath().equals(targetFile.getAbsolutePath())) {
            return node;
        }

        for (int i = 0; i < node.getChildCount(); i++) {
            DefaultMutableTreeNode result = findNodeByFile(
                (DefaultMutableTreeNode) node.getChildAt(i), targetFile);
            if (result != null) return result;
        }

        return null;
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(new java.awt.Color(50, 50, 50));
        label.setFont(new java.awt.Font("Arial", java.awt.Font.PLAIN, 11));
        return label;
    }

    private JTextField createTextField(String text) {
        JTextField field = new JTextField(text);
        field.setBackground(java.awt.Color.WHITE);
        field.setForeground(new java.awt.Color(50, 50, 50));
        field.setBorder(BorderFactory.createLineBorder(new java.awt.Color(200, 200, 200)));
        field.setFont(new java.awt.Font("Arial", java.awt.Font.PLAIN, 11));
        return field;
    }

    private String generateClassContent(String packageName, String className, String modifiers) {
        return String.format(
            "package %s;\n\n" +
            "/**\n" +
            " * Clase: %s\n" +
            " * Creada automáticamente por el IDE\n" +
            " * Fecha: %s\n" +
            " */\n" +
            "%s class %s {\n\n" +
            "    public %s() {\n" +
            "        // Constructor\n" +
            "    }\n\n" +
            "    public static void main(String[] args) {\n" +
            "        System.out.println(\"Hola desde %s\");\n" +
            "    }\n" +
            "}\n",
            packageName,
            className,
            new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm").format(new java.util.Date()),
            modifiers, className, className, className
        );
    }

    private String generatePluginContent(String packageName, String pluginName, String description) {
        return String.format(
            "package %s;\n\n" +
            "/**\n" +
            " * Plugin: %s\n" +
            " * Descripción: %s\n" +
            " * Versión: 1.0.0\n" +
            " * Creado automáticamente por el IDE\n" +
            " * Fecha: %s\n" +
            " */\n" +
            "public class %s {\n\n" +
            "    private String name;\n" +
            "    private String version;\n" +
            "    private boolean enabled;\n\n" +
            "    public %s() {\n" +
            "        this.name = \"%s\";\n" +
            "        this.version = \"1.0.0\";\n" +
            "        this.enabled = false;\n" +
            "    }\n\n" +
            "    public void initialize() {\n" +
            "        System.out.println(\"[\" + name + \"] Inicializando plugin...\");\n" +
            "        this.enabled = true;\n" +
            "    }\n\n" +
            "    public void execute() {\n" +
            "        if (!enabled) {\n" +
            "            System.out.println(\"[\" + name + \"] Plugin desactivado\");\n" +
            "            return;\n" +
            "        }\n" +
            "        System.out.println(\"[\" + name + \"] Ejecutando...\");\n" +
            "    }\n\n" +
            "    public void shutdown() {\n" +
            "        System.out.println(\"[\" + name + \"] Finalizando plugin...\");\n" +
            "        this.enabled = false;\n" +
            "    }\n\n" +
            "    public String getName() { return name; }\n" +
            "    public String getVersion() { return version; }\n" +
            "    public boolean isEnabled() { return enabled; }\n" +
            "}\n",
            packageName, pluginName, description,
            new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm").format(new java.util.Date()),
            pluginName, pluginName, pluginName
        );
    }
}