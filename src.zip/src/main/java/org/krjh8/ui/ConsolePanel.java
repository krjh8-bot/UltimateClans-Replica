package org.krjh8.ui;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class ConsolePanel extends JPanel {
    private JTextArea consoleArea;
    private JScrollPane scrollPane;

    public ConsolePanel() {
        setLayout(new BorderLayout());
        // ⭐ Sin setBackground. FlatDarcula lo pone negro automáticamente.
        
        consoleArea = new JTextArea();
        consoleArea.setEditable(false);
        consoleArea.setFont(new Font("Consolas", Font.PLAIN, 12)); // Un poco más grande para leer bien
        consoleArea.setMargin(new Insets(5, 5, 5, 5));
        consoleArea.setLineWrap(false);
        // ⭐ Sin colores forzados. Darcula pone el fondo negro y las letras grises.

        scrollPane = new JScrollPane(consoleArea);
        // ⭐ Sin bordes manuales para que se integre perfecto con el tema oscuro
        add(scrollPane, BorderLayout.CENTER);
    }

    public void append(String text) {
        consoleArea.append(text + "\n");
        // ⭐ Mejora: Hacer el scroll seguro en el hilo de la UI
        SwingUtilities.invokeLater(() -> {
            scrollPane.getVerticalScrollBar().setValue(scrollPane.getVerticalScrollBar().getMaximum());
        });
    }

    public void clear() {
        consoleArea.setText("");
    }

    public void appendLines(List<String> lines) {
        if (lines != null) {
            for (String line : lines) {
                append(line);
            }
        }
    }

    public void appendError(String error) {
        append(error);
    }

    public String getConsoleText() {
        return consoleArea.getText();
    }
}