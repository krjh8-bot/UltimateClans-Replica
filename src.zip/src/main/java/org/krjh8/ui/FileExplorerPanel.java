package org.krjh8.ui;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import java.awt.*;
import java.io.File;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class FileExplorerPanel extends JPanel {
    private JTree fileTree;
    private File rootDirectory;
    private DefaultMutableTreeNode rootNode;
    private DefaultTreeModel treeModel;
    private FileTreeContextMenu contextMenu;
    private MainFrame mainFrame;

    // Color oscuro para el fondo de los iconos
    private static final Color ICON_BG = new Color(45, 45, 45);

    public FileExplorerPanel(File projectPath, MainFrame mainFrame) {
        setLayout(new BorderLayout());
        this.rootDirectory = projectPath;
        this.mainFrame = mainFrame;

        rootNode = new DefaultMutableTreeNode(projectPath.getName());
        buildTree(rootNode, projectPath);

        treeModel = new DefaultTreeModel(rootNode);
        fileTree = new JTree(treeModel);
        fileTree.setCellRenderer(new FileTreeRenderer());

        contextMenu = new FileTreeContextMenu(this);
        fileTree.addMouseListener(new MouseAdapter() {
            @Override public void mousePressed(MouseEvent e) { if (e.isPopupTrigger()) showContextMenu(e); }
            @Override public void mouseReleased(MouseEvent e) { if (e.isPopupTrigger()) showContextMenu(e); }
            @Override public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && !e.isPopupTrigger()) {
                    File selectedFile = getSelectedFile();
                    if (selectedFile != null && selectedFile.isFile()) fireFileSelectedEvent(selectedFile);
                }
            }
        });

        add(new JScrollPane(fileTree), BorderLayout.CENTER);
    }

    private void showContextMenu(MouseEvent e) {
        int row = fileTree.getRowForLocation(e.getX(), e.getY());
        if (row != -1) {
            fileTree.setSelectionRow(row);
            DefaultMutableTreeNode node = (DefaultMutableTreeNode) fileTree.getLastSelectedPathComponent();
            if (node != null) contextMenu.show(fileTree, e.getX(), e.getY(), buildFileFromNode(node), node);
        }
    }

    private void buildTree(DefaultMutableTreeNode node, File file) {
        if (!file.isDirectory()) return;
        File[] files = file.listFiles();
        if (files == null) return;
        java.util.Arrays.sort(files, (f1, f2) -> {
            if (f1.isDirectory() && !f2.isDirectory()) return -1;
            if (!f1.isDirectory() && f2.isDirectory()) return 1;
            return f1.getName().compareTo(f2.getName());
        });
        for (File child : files) {
            if (child.isHidden()) continue;
            DefaultMutableTreeNode childNode = new DefaultMutableTreeNode(child.getName());
            node.add(childNode);
            if (child.isDirectory()) buildTree(childNode, child);
        }
    }

    public void refreshNode(DefaultMutableTreeNode node) {
        File nodeFile = buildFileFromNode(node);
        if (nodeFile != null && nodeFile.isDirectory()) {
            node.removeAllChildren();
            buildTree(node, nodeFile);
            treeModel.reload(node);
            fileTree.expandPath(new javax.swing.tree.TreePath(node.getPath()));
        } else treeModel.reload(node);
    }

    public void refreshTree() { rootNode.removeAllChildren(); buildTree(rootNode, rootDirectory); treeModel.reload(rootNode); expandAll(); }
    public void expandAll() { for (int i = 0; i < fileTree.getRowCount(); i++) fileTree.expandRow(i); }

    public File getSelectedFile() {
        DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) fileTree.getLastSelectedPathComponent();
        return selectedNode != null ? buildFileFromNode(selectedNode) : null;
    }

    private File buildFileFromNode(DefaultMutableTreeNode node) {
        File current = rootDirectory;
        Object[] pathArray = node.getPath();
        for (int i = 1; i < pathArray.length; i++) current = new File(current, pathArray[i].toString());
        return current;
    }

    public JTree getFileTree() { return fileTree; }
    public File getRootDirectory() { return rootDirectory; }
    
    private java.util.List<FileSelectedListener> listeners = new java.util.ArrayList<>();
    public void addFileSelectedListener(FileSelectedListener listener) { listeners.add(listener); }
    private void fireFileSelectedEvent(File file) { for (FileSelectedListener listener : listeners) listener.fileSelected(file); }

    public interface FileSelectedListener { void fileSelected(File file); }

    private static class FileTreeRenderer extends javax.swing.tree.DefaultTreeCellRenderer {
        @Override
        public java.awt.Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded, boolean leaf, int row, boolean hasFocus) {
            super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);
            if (value instanceof DefaultMutableTreeNode) {
                DefaultMutableTreeNode node = (DefaultMutableTreeNode) value;
                String nodeName = node.getUserObject().toString();
                if (leaf) {
                    setForeground(getColorByExtension(getFileExtension(nodeName).toUpperCase()));
                    Icon icon = createIconForExtension(getFileExtension(nodeName).toUpperCase());
                    setIcon(icon != null ? icon : UIManager.getIcon("FileView.fileIcon"));
                    setText(nodeName);
                } else {
                    setForeground(new Color(187, 187, 187)); // Gris claro para carpetas
                    setIcon(UIManager.getIcon("FileView.directoryIcon"));
                    setText(nodeName);
                }
            }
            return this;
        }

        private String getFileExtension(String fileName) {
            int lastIndex = fileName.lastIndexOf('.');
            return lastIndex > 0 ? fileName.substring(lastIndex + 1) : "FILE";
        }

        private Icon createIconForExtension(String extension) {
            int size = 16;
            switch (extension.toUpperCase()) {
                case "JAVA": return createIcon(size, "J", new Color(200, 40, 41));
                case "YML": case "YAML": return createIcon(size, "Y", new Color(192, 57, 43));
                case "JAR": case "ZIP": return createIcon(size, "Z", new Color(221, 75, 57));
                default: return null;
            }
        }

        private Icon createIcon(int size, String letter, Color color) {
            return new Icon() {
                @Override public void paintIcon(Component c, Graphics g, int x, int y) {
                    Graphics2D g2d = (Graphics2D) g;
                    g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2d.setColor(ICON_BG); // Fondo oscuro para el icono
                    g2d.fillRoundRect(x + 2, y + 2, size - 4, size - 4, 2, 2);
                    g2d.setColor(color);
                    g2d.setStroke(new BasicStroke(1.5f));
                    g2d.drawRoundRect(x + 2, y + 2, size - 4, size - 4, 2, 2);
                    g2d.setFont(new Font("Arial", Font.BOLD, 10));
                    g2d.drawString(letter, x + 5, y + 12);
                }
                @Override public int getIconWidth() { return size; }
                @Override public int getIconHeight() { return size; }
            };
        }

        private Color getColorByExtension(String extension) {
            switch (extension.toUpperCase()) {
                case "JAVA": return new Color(220, 100, 100); // Rojo claro
                case "XML": case "POM": return new Color(230, 150, 80);
                case "PROPERTIES": return new Color(180, 130, 200);
                case "JSON": return new Color(100, 180, 230);
                case "SQL": return new Color(80, 210, 180);
                case "HTML": return new Color(240, 110, 100);
                case "CSS": return new Color(90, 160, 210);
                case "JS": case "JAVASCRIPT": return new Color(245, 215, 70);
                case "YML": case "YAML": return new Color(220, 100, 90);
                default: return new Color(187, 187, 187); // Gris claro por defecto
            }
        }
    }
}