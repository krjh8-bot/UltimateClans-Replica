package org.krjh8.ui;

import org.krjh8.editor.YamlValidator;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;

public class ErrorPanel extends JPanel {
    private JList<String> errorList;
    private DefaultListModel<String> listModel;
    private JLabel errorCountLabel;

    public ErrorPanel() {
        setLayout(new BorderLayout());
        setBackground(new Color(245, 245, 245));
        setBorder(new EmptyBorder(5, 5, 5, 5));

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(new Color(240, 240, 240));
        topPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(200, 200, 200)));

        errorCountLabel = new JLabel("✓ Sin errores");
        errorCountLabel.setFont(new Font("Arial", Font.BOLD, 11));
        errorCountLabel.setForeground(new Color(0, 150, 0));
        errorCountLabel.setBorder(new EmptyBorder(5, 5, 5, 5));
        topPanel.add(errorCountLabel, BorderLayout.WEST);

        add(topPanel, BorderLayout.NORTH);

        listModel = new DefaultListModel<>();
        errorList = new JList<>(listModel);
        errorList.setBackground(Color.WHITE);
        errorList.setForeground(new Color(50, 50, 50));
        errorList.setFont(new Font("Consolas", Font.PLAIN, 10));
        errorList.setCellRenderer(new ErrorCellRenderer());

        JScrollPane scrollPane = new JScrollPane(errorList);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        add(scrollPane, BorderLayout.CENTER);
    }

    public void updateErrors(List<YamlValidator.YamlError> errors) {
        listModel.clear();

        if (errors.isEmpty()) {
            errorCountLabel.setText("✓ Sin errores");
            errorCountLabel.setForeground(new Color(0, 150, 0));
        } else {
            int errorCount = (int) errors.stream()
                .filter(e -> e.type.equals("error")).count();
            int warningCount = (int) errors.stream()
                .filter(e -> e.type.equals("warning")).count();

            StringBuilder label = new StringBuilder();
            if (errorCount > 0) {
                label.append("✗ ").append(errorCount).append(" error(es)");
            }
            if (warningCount > 0) {
                if (label.length() > 0) label.append(" - ");
                label.append("⚠️ ").append(warningCount).append(" advertencia(s)");
            }

            errorCountLabel.setText(label.toString());
            errorCountLabel.setForeground(errorCount > 0 ? Color.RED : new Color(255, 165, 0));

            for (YamlValidator.YamlError error : errors) {
                listModel.addElement(error.toString());
            }
        }
    }

    private static class ErrorCellRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value,
                int index, boolean isSelected, boolean cellHasFocus) {

            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

            if (value instanceof String) {
                String errorText = (String) value;

                if (errorText.contains("ERROR:")) {
                    setForeground(new Color(200, 0, 0));
                    setText("✗ " + errorText);
                } else if (errorText.contains("WARNING:")) {
                    setForeground(new Color(255, 140, 0));
                    setText("⚠️ " + errorText);
                }

                setFont(new Font("Consolas", Font.PLAIN, 10));
            }

            if (isSelected) {
                setBackground(new Color(200, 220, 255));
            } else {
                setBackground(Color.WHITE);
            }

            return this;
        }
    }
}