package org.krjh8.ui;

import org.krjh8.ai.AIManager;
import org.krjh8.ai.AIParser;
import org.krjh8.ai.AIAction;
import org.krjh8.ai.ActionExecutor;
import org.krjh8.util.PomXmlReader;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AIPanelManager extends JPanel {
    private static final Logger LOGGER = Logger.getLogger(AIPanelManager.class.getName());

    private JTextArea outputArea;
    private JTextArea memoryArea;
    private JTextField inputField;
    private JScrollPane scrollPane;
    private JScrollPane memoryScrollPane;
    private JButton configBtn;
    private JButton clearMemoryBtn;
    private JLabel statusLabel;
    private JLabel pomInfoLabel;
    private ExecutorService executor;
    private AIManager aiManager;
    private File projectRoot;
    private PomXmlReader pomReader;
    private boolean isProcessing = false;
    
    private StringBuilder conversationMemory;
    private List<String> conversationHistory;
    private int maxMemoryLines = 50;

    private static final Color BG_COLOR = new Color(30, 30, 30);
    private static final Color TEXT_COLOR = new Color(220, 220, 220);
    private static final Color PROMPT_COLOR = new Color(100, 200, 100);
    private static final Color ERROR_COLOR = new Color(255, 100, 100);
    private static final Color SUCCESS_COLOR = new Color(100, 200, 100);
    private static final Color WARNING_COLOR = new Color(255, 200, 100);
    private static final Color INFO_COLOR = new Color(100, 150, 255);
    private static final Font TERMINAL_FONT = new Font("Consolas", Font.PLAIN, 11);

    public AIPanelManager(File projectRoot) {
        setLayout(new BorderLayout());
        setBackground(BG_COLOR);
        setBorder(new EmptyBorder(5, 5, 5, 5));
        setPreferredSize(new Dimension(0, 300));

        this.projectRoot = projectRoot;
        this.pomReader = projectRoot != null ? new PomXmlReader(projectRoot) : null;
        this.aiManager = new AIManager();
        this.executor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "AIPanel-Worker");
            t.setDaemon(true);
            return t;
        });
        
        this.conversationMemory = new StringBuilder();
        this.conversationHistory = new ArrayList<>();

        setupUI();
        initializePanel();
    }

    private void setupUI() {
        
        JPanel topPanel = new JPanel(new BorderLayout(5, 5));
        topPanel.setBackground(BG_COLOR);

        JPanel consolePanel = new JPanel(new BorderLayout());
        consolePanel.setBackground(BG_COLOR);

        JLabel consoleLabel = new JLabel("📋 Consola");
        consoleLabel.setForeground(INFO_COLOR);
        consoleLabel.setFont(new Font("Arial", Font.BOLD, 12));
        consoleLabel.setBorder(new EmptyBorder(5, 5, 5, 5));
        consolePanel.add(consoleLabel, BorderLayout.NORTH);

        outputArea = new JTextArea();
        outputArea.setEditable(false);
        outputArea.setBackground(BG_COLOR);
        outputArea.setForeground(TEXT_COLOR);
        outputArea.setFont(TERMINAL_FONT);
        outputArea.setCaretColor(TEXT_COLOR);
        outputArea.setLineWrap(true);
        outputArea.setWrapStyleWord(true);
        outputArea.setMargin(new Insets(5, 5, 5, 5));

        scrollPane = new JScrollPane(outputArea);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(60, 60, 60)));
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        consolePanel.add(scrollPane, BorderLayout.CENTER);

        JPanel memoryPanel = new JPanel(new BorderLayout());
        memoryPanel.setBackground(BG_COLOR);

        JPanel memoryHeaderPanel = new JPanel(new BorderLayout());
        memoryHeaderPanel.setBackground(BG_COLOR);

        JLabel memoryLabel = new JLabel("🧠 Memoria");
        memoryLabel.setForeground(PROMPT_COLOR);
        memoryLabel.setFont(new Font("Arial", Font.BOLD, 12));
        memoryLabel.setBorder(new EmptyBorder(5, 5, 5, 5));
        memoryHeaderPanel.add(memoryLabel, BorderLayout.WEST);

        clearMemoryBtn = new JButton("🗑️");
        clearMemoryBtn.setBackground(new Color(180, 60, 60));
        clearMemoryBtn.setForeground(Color.WHITE);
        clearMemoryBtn.setFocusPainted(false);
        clearMemoryBtn.setToolTipText("Limpiar memoria");
        clearMemoryBtn.setPreferredSize(new Dimension(35, 25));
        clearMemoryBtn.addActionListener(e -> clearMemory());
        memoryHeaderPanel.add(clearMemoryBtn, BorderLayout.EAST);

        memoryPanel.add(memoryHeaderPanel, BorderLayout.NORTH);

        memoryArea = new JTextArea();
        memoryArea.setEditable(false);
        memoryArea.setBackground(new Color(40, 40, 40));
        memoryArea.setForeground(PROMPT_COLOR);
        memoryArea.setFont(new Font("Consolas", Font.PLAIN, 10));
        memoryArea.setCaretColor(PROMPT_COLOR);
        memoryArea.setLineWrap(true);
        memoryArea.setWrapStyleWord(true);
        memoryArea.setMargin(new Insets(5, 5, 5, 5));

        memoryScrollPane = new JScrollPane(memoryArea);
        memoryScrollPane.setBorder(BorderFactory.createLineBorder(new Color(80, 80, 80)));
        memoryScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        memoryPanel.add(memoryScrollPane, BorderLayout.CENTER);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, consolePanel, memoryPanel);
        splitPane.setDividerLocation(0.7);
        splitPane.setResizeWeight(0.7);
        splitPane.setBackground(BG_COLOR);
        splitPane.setDividerSize(5);

        topPanel.add(splitPane, BorderLayout.CENTER);

        add(topPanel, BorderLayout.CENTER);

        JPanel pomPanel = new JPanel(new BorderLayout());
        pomPanel.setBackground(new Color(40, 40, 40));
        pomPanel.setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, new Color(60, 60, 60)));
        pomPanel.setPreferredSize(new Dimension(0, 40));

        pomInfoLabel = new JLabel("📦 Sin proyecto abierto");
        pomInfoLabel.setForeground(WARNING_COLOR);
        pomInfoLabel.setFont(new Font("Arial", Font.PLAIN, 11));
        pomInfoLabel.setBorder(new EmptyBorder(5, 10, 5, 10));
        pomPanel.add(pomInfoLabel, BorderLayout.CENTER);

        add(pomPanel, BorderLayout.NORTH);

        JPanel inputPanel = new JPanel(new BorderLayout(5, 0));
        inputPanel.setBackground(BG_COLOR);
        inputPanel.setBorder(new EmptyBorder(5, 0, 0, 0));

        JLabel promptLabel = new JLabel("IA> ");
        promptLabel.setForeground(PROMPT_COLOR);
        promptLabel.setFont(TERMINAL_FONT);
        promptLabel.setBorder(new EmptyBorder(0, 5, 0, 5));

        inputField = new JTextField();
        inputField.setBackground(new Color(40, 40, 40));
        inputField.setForeground(TEXT_COLOR);
        inputField.setFont(TERMINAL_FONT);
        inputField.setCaretColor(TEXT_COLOR);
        inputField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(80, 80, 80)),
                new EmptyBorder(5, 5, 5, 5)
        ));

        inputField.addKeyListener(new java.awt.event.KeyListener() {
            @Override
            public void keyPressed(java.awt.event.KeyEvent e) {
                if (e.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
                    if (!isProcessing) {
                        processUserInput();
                    } else {
                        appendOutput("⏳ Esperando respuesta anterior...", WARNING_COLOR);
                    }
                    e.consume();
                }
            }

            @Override
            public void keyTyped(java.awt.event.KeyEvent e) {}

            @Override
            public void keyReleased(java.awt.event.KeyEvent e) {}
        });

        JPanel leftPanel = new JPanel(new BorderLayout());
        leftPanel.setBackground(BG_COLOR);
        leftPanel.add(promptLabel, BorderLayout.WEST);
        leftPanel.add(inputField, BorderLayout.CENTER);

        inputPanel.add(leftPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
        buttonPanel.setBackground(BG_COLOR);

        statusLabel = new JLabel("✓ Listo");
        statusLabel.setForeground(SUCCESS_COLOR);
        statusLabel.setFont(new Font("Arial", Font.PLAIN, 10));
        statusLabel.setBorder(new EmptyBorder(0, 10, 0, 10));

        configBtn = new JButton("⚙️");
        configBtn.setBackground(new Color(60, 120, 180));
        configBtn.setForeground(Color.WHITE);
        configBtn.setFocusPainted(false);
        configBtn.setToolTipText("Información");
        configBtn.setPreferredSize(new Dimension(40, 30));
        configBtn.addActionListener(e -> showInfoDialog());

        buttonPanel.add(statusLabel);
        buttonPanel.add(configBtn);

        inputPanel.add(buttonPanel, BorderLayout.EAST);

        add(inputPanel, BorderLayout.SOUTH);
    }

    private void initializePanel() {
        appendOutput("╔════════════════════════════════════════════════════════════╗");
        appendOutput("║          🤖 ASISTENTE IA - Java Plugin IDE v2.0            ║");
        appendOutput("╠════════════════════════════════════════════════════════════╣");
        appendOutput("║  🧠 MEMORIA: Este panel guarda el historial de comandos   ║");
        appendOutput("║  📦 POM.XML: Lee automáticamente GroupId, ArtifactId       ║");
        appendOutput("║  ⚡ PODER: Usa IA para crear/modificar archivos            ║");
        appendOutput("║                                                            ║");
        appendOutput("║  Ejemplos de comandos:                                     ║");
        appendOutput("║    > create a command /hola that says Hola in minecraft    ║");
        appendOutput("║    > create a listener for player join event               ║");
        appendOutput("║    > create the plugin.yml file with proper config         ║");
        appendOutput("║    > create a main class with @Override methods            ║");
        appendOutput("║                                                            ║");
        appendOutput("║  Presiona ENTER para enviar el - by krjh8                  ║");
        appendOutput("╚════════════════════════════════════════════════════════════╝\n");
        
        updateStatus("Listo", SUCCESS_COLOR);
        updatePomInfo();
    }


    private void updatePomInfo() {
        if (pomReader != null) {
            try {
                String groupId = pomReader.getGroupId();
                String artifactId = pomReader.getArtifactId();
                String version = pomReader.getVersion();

                if (groupId != null && artifactId != null && version != null) {
                    pomInfoLabel.setText(
                        "📦 GroupId: " + groupId + " | ArtifactId: " + artifactId + " | Version: " + version
                    );
                    pomInfoLabel.setForeground(SUCCESS_COLOR);
                    
                    addToMemory("[POM.XML] GroupId: " + groupId);
                    addToMemory("[POM.XML] ArtifactId: " + artifactId);
                    addToMemory("[POM.XML] Version: " + version);
                    
                    LOGGER.info("Información del pom.xml cargada");
                } else {
                    pomInfoLabel.setText("⚠️ No se pudo leer pom.xml completo");
                    pomInfoLabel.setForeground(WARNING_COLOR);
                }
            } catch (Exception e) {
                pomInfoLabel.setText("❌ Error leyendo pom.xml: " + e.getMessage());
                pomInfoLabel.setForeground(ERROR_COLOR);
                LOGGER.log(Level.WARNING, "Error leyendo pom.xml", e);
            }
        } else {
            pomInfoLabel.setText("📦 Sin proyecto abierto");
            pomInfoLabel.setForeground(WARNING_COLOR);
        }
    }

    private void processUserInput() {
        String userInput = inputField.getText().trim();

        if (userInput.isEmpty()) {
            return;
        }

        appendOutput("> " + userInput, PROMPT_COLOR);
        
        addToMemory("USER: " + userInput);
        
        inputField.setText("");
        inputField.setEnabled(false);
        isProcessing = true;

        updateStatus("Procesando...", INFO_COLOR);

        executor.submit(() -> {
            try {
                if (projectRoot == null || pomReader == null) {
                    appendOutput("❌ Error: No hay proyecto abierto", ERROR_COLOR);
                    appendOutput("Por favor, abre un proyecto primero", WARNING_COLOR);
                    addToMemory("ERROR: No hay proyecto abierto");
                    return;
                }

                appendOutput("🔄 Conectando con IA...", INFO_COLOR);

                String groupId = pomReader.getGroupId();
                String artifactId = pomReader.getArtifactId();
                
                String enhancedInput = userInput + 
                    "\n\n[Contexto del proyecto]\nGroupId: " + groupId + 
                    "\nArtifactId: " + artifactId +
                    "\n[Historial reciente]\n" + getRecentMemory();

                String aiResponse = aiManager.sendPrompt(enhancedInput);
                
                appendOutput("✓ Respuesta recibida", SUCCESS_COLOR);
                appendOutput("");

                addToMemory("IA: " + aiResponse.substring(0, Math.min(100, aiResponse.length())) + "...");

                AIParser parser = new AIParser();
                List<AIAction> actions = parser.parseActions(aiResponse);

                if (actions.isEmpty()) {
                    appendOutput("⚠️ La IA no generó acciones válidas", WARNING_COLOR);
                    addToMemory("No se generaron acciones");
                    return;
                }

                appendOutput("📋 Acciones a ejecutar: " + actions.size() + "\n", INFO_COLOR);

                ActionExecutor actionExecutor = new ActionExecutor(projectRoot);
                List<String> logs = actionExecutor.executeActions(actions);

                for (String log : logs) {
                    if (log.contains("✅")) {
                        appendOutput(log, SUCCESS_COLOR);
                        addToMemory(log);
                    } else if (log.contains("❌")) {
                        appendOutput(log, ERROR_COLOR);
                        addToMemory(log);
                    } else if (log.contains("⚠️")) {
                        appendOutput(log, WARNING_COLOR);
                        addToMemory(log);
                    } else if (log.contains("ℹ️")) {
                        appendOutput(log, INFO_COLOR);
                    } else if (log.contains("📊") || log.contains("─")) {
                        appendOutput(log, PROMPT_COLOR);
                    } else if (log.contains("🔄")) {
                        appendOutput(log, INFO_COLOR);
                    } else {
                        appendOutput(log);
                    }
                }

                appendOutput("");
                updateStatus("✓ Completado", SUCCESS_COLOR);
                addToMemory("COMPLETADO");

            } catch (IllegalArgumentException e) {
                appendOutput("❌ Error de configuración: " + e.getMessage(), ERROR_COLOR);
                addToMemory("ERROR: " + e.getMessage());
                updateStatus("Error", ERROR_COLOR);
            } catch (Exception e) {
                appendOutput("❌ Error: " + e.getMessage(), ERROR_COLOR);
                addToMemory("ERROR: " + e.getMessage());
                LOGGER.log(Level.SEVERE, "Error procesando solicitud IA", e);
                updateStatus("Error", ERROR_COLOR);
            } finally {
                SwingUtilities.invokeLater(() -> {
                    inputField.setEnabled(true);
                    inputField.requestFocus();
                    isProcessing = false;
                });
            }
        });
    }

    private void addToMemory(String text) {
        SwingUtilities.invokeLater(() -> {
            conversationHistory.add(text);
            
            if (conversationHistory.size() > maxMemoryLines) {
                conversationHistory.remove(0);
            }
            
            updateMemoryDisplay();
        });
    }

    private void updateMemoryDisplay() {
        StringBuilder memory = new StringBuilder();
        for (String line : conversationHistory) {
            memory.append(line).append("\n");
        }
        memoryArea.setText(memory.toString());
        
        memoryArea.setCaretPosition(memoryArea.getDocument().getLength());
    }

    private String getRecentMemory() {
        StringBuilder recent = new StringBuilder();
        int start = Math.max(0, conversationHistory.size() - 5);
        
        for (int i = start; i < conversationHistory.size(); i++) {
            recent.append(conversationHistory.get(i)).append("\n");
        }
        
        return recent.toString();
    }

    private void clearMemory() {
        int confirm = JOptionPane.showConfirmDialog(
            this,
            "¿Limpiar toda la memoria de conversación?",
            "Confirmar", JOptionPane.YES_NO_OPTION
        );
        
        if (confirm == JOptionPane.YES_OPTION) {
            conversationHistory.clear();
            updateMemoryDisplay();
            appendOutput("🗑️ Memoria limpiada", WARNING_COLOR);
        }
    }

    private void showInfoDialog() {
        JDialog dialog = new JDialog(
                (JFrame) SwingUtilities.getWindowAncestor(this),
                "Información - IA Assistant v2.0", true);
        dialog.setSize(600, 380);
        dialog.setLocationRelativeTo(this);
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        dialog.getContentPane().setBackground(new Color(245, 245, 245));

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(245, 245, 245));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel titleLabel = new JLabel("🤖 Asistente IA v2.0");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setForeground(new Color(0, 102, 204));
        mainPanel.add(titleLabel, BorderLayout.NORTH);

        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBackground(new Color(240, 248, 255));
        contentPanel.setBorder(BorderFactory.createLineBorder(new Color(100, 150, 255)));

        JLabel infoLabel = new JLabel(
            "<html><b>✅ Estado:</b><br>" +
            "✓ API Key: " + aiManager.getApiKeyMasked() + "<br>" +
            "✓ Modelo: gpt-4o-mini<br>" +
            "✓ Memoria: Habilitada<br>" +
            "✓ POM.XML: Lector integrado<br>" +
            "<br>" +
            "<b>🎯 Características v2.0:</b><br>" +
            "• 🧠 Memoria de conversación (últimas 50 líneas)<br>" +
            "• 📦 Lectura automática de pom.xml<br>" +
            "• 💾 Soporte GroupId/ArtifactId<br>" +
            "• 📝 Crear, modificar, eliminar y leer archivos<br>" +
            "• 🎨 Interfaz mejorada con historial<br>" +
            "• ⚡ Contexto del proyecto en cada solicitud<br>" +
            "<br>" +
            "<b>💡 Consejos:</b><br>" +
            "• La IA usa el contexto del pom.xml<br>" +
            "• La memoria se borra al hacer clic en 🗑️<br>" +
            "• Cada comando se guarda automáticamente<br>" +
            "• El historial ayuda a la IA a entender mejor<br>" +
            "</html>"
        );
        infoLabel.setForeground(new Color(50, 50, 50));
        infoLabel.setFont(new Font("Arial", Font.PLAIN, 11));
        infoLabel.setBorder(new EmptyBorder(10, 10, 10, 10));
        contentPanel.add(infoLabel, BorderLayout.CENTER);

        mainPanel.add(contentPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttonPanel.setBackground(new Color(245, 245, 245));

        JButton okBtn = new JButton("✓ Cerrar");
        okBtn.setBackground(new Color(0, 150, 0));
        okBtn.setForeground(Color.WHITE);
        okBtn.setFocusPainted(false);
        okBtn.addActionListener(e -> dialog.dispose());

        buttonPanel.add(okBtn);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        dialog.add(mainPanel);
        dialog.setVisible(true);
    }

    private void appendOutput(String text, Color color) {
        SwingUtilities.invokeLater(() -> {
            try {
                outputArea.append(text + "\n");
                
                outputArea.setCaretPosition(outputArea.getDocument().getLength());
            } catch (Exception e) {
                LOGGER.log(Level.WARNING, "Error añadiendo output", e);
            }
        });
    }

    private void appendOutput(String text) {
        appendOutput(text, TEXT_COLOR);
    }

    private void clearOutput() {
        SwingUtilities.invokeLater(() -> {
            outputArea.setText("");
            initializePanel();
        });
    }

    private void updateStatus(String status, Color color) {
        SwingUtilities.invokeLater(() -> {
            statusLabel.setText(status);
            statusLabel.setForeground(color);
        });
    }

    public void setProjectRoot(File projectRoot) {
        this.projectRoot = projectRoot;
        
        if (projectRoot != null) {
            this.pomReader = new PomXmlReader(projectRoot);
            
            SwingUtilities.invokeLater(() -> {
                appendOutput("✓ Proyecto actualizado: " + projectRoot.getName(), SUCCESS_COLOR);
                addToMemory("PROJECT_LOADED: " + projectRoot.getName());
                updateStatus("Proyecto cargado", SUCCESS_COLOR);
                updatePomInfo();
            });
        }
    }

    public File getProjectRoot() {
        return projectRoot;
    }

    public boolean isProcessing() {
        return isProcessing;
    }

    public void focusInput() {
        inputField.requestFocus();
    }

    public void dispose() {
        if (executor != null && !executor.isShutdown()) {
            executor.shutdownNow();
        }
    }

    public AIManager getAIManager() {
        return aiManager;
    }

    public List<String> getMemory() {
        return new ArrayList<>(conversationHistory);
    }
}