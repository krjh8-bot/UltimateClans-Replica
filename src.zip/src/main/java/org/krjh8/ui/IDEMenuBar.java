package org.krjh8.ui;

import javax.swing.*;
import java.awt.event.ActionListener;

public class IDEMenuBar extends JMenuBar {
    private JMenu fileMenu;
    private JMenu projectMenu;
    private JMenu buildMenu;
    private JMenu viewMenu;
    private JMenu helpMenu;

    private JMenuItem newProjectItem;
    private JMenuItem openProjectItem;
    private JMenuItem exitItem;
    
    private JMenuItem compileItem;
    private JMenuItem buildJarItem;
    private JMenuItem runTestsItem;
    
    private JMenuItem refactorImportsItem;
    private JMenuItem removeCommentsItem;
    
    private JMenuItem settingsItem;
    private JMenuItem aiItem;

    public IDEMenuBar() {
        fileMenu = new JMenu("Archivo");
        newProjectItem = new JMenuItem("Nuevo Proyecto");
        openProjectItem = new JMenuItem("Abrir Proyecto");
        exitItem = new JMenuItem("Salir");
        
        fileMenu.add(newProjectItem);
        fileMenu.add(openProjectItem);
        fileMenu.addSeparator();
        fileMenu.add(exitItem);
        add(fileMenu);

        projectMenu = new JMenu("Proyecto");
        settingsItem = new JMenuItem("Configuración");
        projectMenu.add(settingsItem);
        add(projectMenu);

        buildMenu = new JMenu("Construir");
        compileItem = new JMenuItem("Compilar");
        buildJarItem = new JMenuItem("Build JAR");
        runTestsItem = new JMenuItem("Ejecutar Tests");
        
        buildMenu.add(compileItem);
        buildMenu.add(buildJarItem);
        buildMenu.addSeparator();
        buildMenu.add(runTestsItem);
        add(buildMenu);

        viewMenu = new JMenu("Ver");
        refactorImportsItem = new JMenuItem("🔄 Refactor Imports");
        removeCommentsItem = new JMenuItem("🧹 Limpiar Comentarios");
        viewMenu.add(refactorImportsItem);
        viewMenu.add(removeCommentsItem);
        add(viewMenu);

        helpMenu = new JMenu("IA");
        aiItem = new JMenuItem("🤖 Abrir Asistente IA");
        helpMenu.add(aiItem);
        add(helpMenu);
    }

    public void addNewProjectListener(ActionListener listener) { newProjectItem.addActionListener(listener); }
    public void addOpenProjectListener(ActionListener listener) { openProjectItem.addActionListener(listener); }
    public void addExitListener(ActionListener listener) { exitItem.addActionListener(listener); }
    public void addCompileListener(ActionListener listener) { compileItem.addActionListener(listener); }
    public void addBuildJarListener(ActionListener listener) { buildJarItem.addActionListener(listener); }
    public void addRunTestsListener(ActionListener listener) { runTestsItem.addActionListener(listener); }
    public void addSettingsListener(ActionListener listener) { settingsItem.addActionListener(listener); }
    public void addAIListener(ActionListener listener) { aiItem.addActionListener(listener); }
    
    // ⭐ NUEVOS LISTENERS PARA "VER"
    public void addRefactorImportsListener(ActionListener listener) { refactorImportsItem.addActionListener(listener); }
    public void addRemoveCommentsListener(ActionListener listener) { removeCommentsItem.addActionListener(listener); }
}