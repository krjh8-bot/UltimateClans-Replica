package org.krjh8.ui;

import org.krjh8.file.FileManager;
import org.krjh8.editor.SyntaxHighlighter;
import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
import org.fife.ui.rsyntaxtextarea.SyntaxConstants;
import org.fife.ui.rtextarea.RTextScrollPane;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.Timer;
import java.util.TimerTask;

public class EditorPanel extends JPanel {
    private RSyntaxTextArea textArea;
    private RTextScrollPane scrollPane;
    private File currentFile;
    private Timer autoSaveTimer;
    private boolean modified;
    private JLabel fileInfoLabel;

    public EditorPanel() {
        setLayout(new BorderLayout());
        
        fileInfoLabel = new JLabel("Sin archivo abierto");
        fileInfoLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        fileInfoLabel.setOpaque(true);
        fileInfoLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        add(fileInfoLabel, BorderLayout.NORTH);

        textArea = createEditor();
        scrollPane = SyntaxHighlighter.createScrollPane(textArea);
        
        // ⭐ Se añade el scrollPane directo, ya no hay splitPane con errores
        add(scrollPane, BorderLayout.CENTER);

        textArea.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { modified = true; updateFileInfo(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { modified = true; updateFileInfo(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { modified = true; updateFileInfo(); }
        });

        initAutoSave();
    }

    private RSyntaxTextArea createEditor() {
        RSyntaxTextArea textArea = new RSyntaxTextArea(25, 80);
        textArea.setCodeFoldingEnabled(true);
        textArea.setMarkOccurrences(true);
        textArea.setAutoIndentEnabled(true);
        textArea.setFont(new Font("Consolas", Font.PLAIN, 14));
        
        // ⭐ COLORES EXACTOS DE INTELLIJ DARK (DARCULA)
        textArea.setBackground(new Color(43, 43, 43)); // Fondo principal oscuro
        textArea.setForeground(new Color(187, 187, 187)); // Texto normal gris claro
        textArea.setCaretColor(Color.WHITE); // Cursor blanco
        textArea.setSelectionColor(new Color(75, 110, 175)); // Selección azul oscuro
        textArea.setCurrentLineHighlightColor(new Color(50, 50, 50)); // Línea actual
        textArea.setMarginLineEnabled(true);
        textArea.setMarginLineColor(new Color(80, 80, 80)); // Línea de margen
        
        return textArea;
    }

    private void initAutoSave() {
        autoSaveTimer = new Timer();
        autoSaveTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                if (modified && currentFile != null) {
                    saveFile();
                    modified = false;
                }
            }
        }, 30000, 30000);
    }

    public void openFile(File file) {
        if (file != null && file.exists()) {
            String content = FileManager.readFile(file);
            textArea.setText("");
            
            String[] lines = content.split("\n", -1);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < lines.length; i++) {
                sb.append(lines[i]);
                if (i < lines.length - 1) sb.append("\n");
            }
            textArea.setText(sb.toString());
            
            String fileName = file.getName().toLowerCase();
            if (fileName.endsWith(".java")) textArea.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_JAVA);
            else if (fileName.endsWith(".xml") || fileName.endsWith(".pom")) textArea.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_XML);
            else if (fileName.endsWith(".properties")) textArea.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_PROPERTIES_FILE);
            else if (fileName.endsWith(".json")) textArea.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_JSON);
            else if (fileName.endsWith(".sql")) textArea.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_SQL);
            else if (fileName.endsWith(".html") || fileName.endsWith(".htm")) textArea.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_HTML);
            else if (fileName.endsWith(".css")) textArea.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_CSS);
            else if (fileName.endsWith(".js")) textArea.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_JAVASCRIPT);
            else if (fileName.endsWith(".py")) textArea.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_PYTHON);
            else if (fileName.endsWith(".yml") || fileName.endsWith(".yaml")) textArea.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_YAML);
            else if (fileName.endsWith(".gradle")) textArea.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_GROOVY);
            else if (fileName.endsWith(".sh") || fileName.endsWith(".bash")) textArea.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_UNIX_SHELL);
            else if (fileName.endsWith(".bat") || fileName.endsWith(".cmd")) textArea.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_WINDOWS_BATCH);
            else textArea.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_NONE);
            
            this.currentFile = file;
            this.modified = false;
            updateFileInfo();
            textArea.setCaretPosition(0);
            scrollPane.getVerticalScrollBar().setValue(0);
        }
    }

    public boolean saveFile() {
        if (currentFile != null) {
            boolean success = FileManager.writeFile(currentFile, textArea.getText());
            if (success) { modified = false; updateFileInfo(); }
            return success;
        }
        return false;
    }

    public void newFile(File file) {
        textArea.setText("");
        this.currentFile = file;
        this.modified = false;
        updateFileInfo();
    }

    private void updateFileInfo() {
        if (currentFile != null) {
            String fileName = currentFile.getName();
            int lines = textArea.getLineCount();
            int chars = textArea.getText().length();
            String status = modified ? "● (modificado)" : "✓ (guardado)";
            double sizeKB = currentFile.length() / 1024.0;
            String sizeStr = String.format("%.1f KB", sizeKB);
            fileInfoLabel.setText(String.format("📄 %s | Líneas: %d | Caracteres: %d | Tamaño: %s | %s", fileName, lines, chars, sizeStr, status));
        } else {
            fileInfoLabel.setText("Sin archivo abierto");
        }
    }

    public String getText() { return textArea.getText(); }
    public void setText(String text) { textArea.setText(text); modified = false; }
    public RSyntaxTextArea getTextArea() { return textArea; }
    public File getCurrentFile() { return currentFile; }
    public boolean isModified() { return modified; }
    
    public void clear() { textArea.setText(""); modified = false; currentFile = null; updateFileInfo(); }
    public void selectAll() { textArea.selectAll(); }
    public void copy() { textArea.copy(); }
    public void cut() { textArea.cut(); }
    public void paste() { textArea.paste(); }
    
    public int findText(String searchText) {
        String content = textArea.getText();
        int index = content.indexOf(searchText);
        if (index >= 0) { textArea.setCaretPosition(index); textArea.select(index, index + searchText.length()); }
        return index;
    }

    public int replaceText(String searchText, String replaceText) {
        String content = textArea.getText();
        int index = content.indexOf(searchText);
        if (index >= 0) {
            textArea.setText(content.substring(0, index) + replaceText + content.substring(index + searchText.length()));
            modified = true; updateFileInfo(); return index;
        }
        return -1;
    }

    public int replaceAll(String searchText, String replaceText) {
        String content = textArea.getText();
        String newContent = content.replaceAll(java.util.regex.Pattern.quote(searchText), java.util.regex.Matcher.quoteReplacement(replaceText));
        int count = (content.length() - newContent.length()) / searchText.length();
        if (count > 0) { textArea.setText(newContent); modified = true; updateFileInfo(); }
        return count;
    }

    public void dispose() { if (autoSaveTimer != null) autoSaveTimer.cancel(); }
}