package org.krjh8.util;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.logging.Logger;
import java.util.logging.Level;

/**
 * Lee información del pom.xml del proyecto
 */
public class PomXmlReader {
    private static final Logger LOGGER = Logger.getLogger(PomXmlReader.class.getName());
    private File projectRoot;
    private File pomFile;

    public PomXmlReader(File projectRoot) {
        this.projectRoot = projectRoot;
        this.pomFile = new File(projectRoot, "pom.xml");
    }

    /**
     * Obtiene el GroupId del proyecto
     */
    public String getGroupId() {
        return extractTagValue("groupId");
    }

    /**
     * Obtiene el ArtifactId del proyecto
     */
    public String getArtifactId() {
        return extractTagValue("artifactId");
    }

    /**
     * Obtiene la versión del proyecto
     */
    public String getVersion() {
        return extractTagValue("version");
    }

    /**
     * Obtiene la ruta src/main/java
     */
    public File getSourceDirectory() {
        return new File(projectRoot, "src/main/java");
    }

    /**
     * Obtiene la ruta src/main/resources
     */
    public File getResourcesDirectory() {
        return new File(projectRoot, "src/main/resources");
    }

    /**
     * Obtiene la ruta src/test/java
     */
    public File getTestDirectory() {
        return new File(projectRoot, "src/test/java");
    }

    /**
     * Extrae el valor de un tag XML del pom.xml
     */
    private String extractTagValue(String tagName) {
        try {
            if (!pomFile.exists()) {
                LOGGER.warning("pom.xml no encontrado en: " + projectRoot.getAbsolutePath());
                return null;
            }

            String content = new String(Files.readAllBytes(pomFile.toPath()));
            
            // Expresión regular para encontrar el valor del tag
            Pattern pattern = Pattern.compile("<" + tagName + ">(.*?)</" + tagName + ">");
            Matcher matcher = pattern.matcher(content);

            if (matcher.find()) {
                return matcher.group(1).trim();
            }

            LOGGER.warning("Tag '" + tagName + "' no encontrado en pom.xml");
            return null;

        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error leyendo pom.xml: " + e.getMessage(), e);
            return null;
        }
    }

    /**
     * Obtiene el path base del proyecto
     */
    public File getProjectRoot() {
        return projectRoot;
    }

    /**
     * Convierte un nombre de paquete en ruta
     */
    public File getPackagePath(String packageName) {
        File sourceDir = getSourceDirectory();
        String[] packages = packageName.split("\\.");
        
        File packagePath = sourceDir;
        for (String pkg : packages) {
            packagePath = new File(packagePath, pkg);
        }
        
        return packagePath;
    }

    /**
     * Obtiene el path de recursos basado en paquete
     */
    public File getResourcePackagePath(String packageName) {
        File resourcesDir = getResourcesDirectory();
        String[] packages = packageName.split("\\.");
        
        File packagePath = resourcesDir;
        for (String pkg : packages) {
            packagePath = new File(packagePath, pkg);
        }
        
        return packagePath;
    }
}