package org.krjh8;

import org.krjh8.ui.MainFrame;
import org.krjh8.config.EnvironmentDetector;
import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        if (!EnvironmentDetector.validateEnvironment()) {
            JOptionPane.showMessageDialog(null,
                "Error: Java JDK 21 y Maven no están correctamente instalados.",
                "Error de Configuración",
                JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        SwingUtilities.invokeLater(() -> {
            MainFrame frame = new MainFrame();
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setVisible(true);
        });
    }
}