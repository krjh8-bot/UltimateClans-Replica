package org.krjh8.ui.dialogs;

import org.krjh8.editor.UsageSearcher.UsageResult;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.File;

public class UsagesDialog extends JDialog {
    private final File projectRoot;
    private final FileNavigationListener navigationListener;

    public interface FileNavigationListener {
        void navigateToFile(File file, int lineNumber);
    }

    public UsagesDialog(JFrame parent, String searchedWord, File projectRoot, java.util.List<UsageResult> results, FileNavigationListener listener) {
        super(parent, "Find Usages", false); // false = no modal, para poder seguir editando
        this.projectRoot = projectRoot;
        this.navigationListener = listener;
        
        setSize(600, 450);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        
        setupUI(searchedWord, results);
    }

    private void setupUI(String searchedWord, java.util.List<UsageResult> results) {
        JPanel mainPanel = new JPanel(new BorderLayout(5, 5));
        mainPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        // Cabecera
        JLabel headerLabel = new JLabel("Usages of '" + searchedWord + "' in Project");
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        headerLabel.setBorder(new EmptyBorder(0, 0, 5, 0));
        mainPanel.add(headerLabel, BorderLayout.NORTH);

        // Resumen
        JLabel countLabel = new JLabel(results.size() + " usages found");
        countLabel.setForeground(new Color(150, 150, 150));
        countLabel.setBorder(new EmptyBorder(0, 0, 10, 0));
        mainPanel.add(countLabel, BorderLayout.SOUTH);

        // Lista de resultados
        DefaultListModel<String> listModel = new DefaultListModel<>();
        for (UsageResult result : results) {
            String relativePath = result.getRelativePath(projectRoot);
            // Formato: ruta (línea): texto
            listModel.addElement("<html><b>" + relativePath + "</b> <font color='#888'>[" + result.getLineNumber() + "]</font><br>&nbsp;&nbsp;&nbsp;&nbsp;<font color='#AAA'>" + escapeHtml(result.getLineText()) + "</font></html>");
        }

        JList<String> resultList = new JList<>(listModel);
        resultList.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (isSelected) {
                    setBackground(new Color(75, 110, 175)); // Azul oscuro al seleccionar
                    setForeground(Color.WHITE);
                } else {
                    setBackground(list.getBackground());
                    setForeground(list.getForeground());
                }
                setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
                return label;
            }
        });

        // Doble click para navegar
        resultList.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int selectedIndex = resultList.getSelectedIndex();
                    if (selectedIndex != -1 && navigationListener != null) {
                        UsageResult selected = results.get(selectedIndex);
                        navigationListener.navigateToFile(selected.getFile(), selected.getLineNumber());
                        dispose(); // Cerrar diálogo al navegar
                    }
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(resultList);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        add(mainPanel);
    }

    private String escapeHtml(String text) {
        return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}