package org.krjh8.ui.dialogs;

import org.krjh8.refactor.CommentRemover;
import org.krjh8.refactor.CommentRemover.RemovalResult;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.List;

public class RemoveCommentsDialog extends JDialog {
    
    private final File projectRoot;
    private final ConsoleAppender consoleAppender;
    
    private JCheckBox removeSingleLineCheck;
    private JCheckBox removeMultiLineCheck;
    private JCheckBox previewOnlyCheck;
    private JTextArea previewArea;
    private JButton previewBtn;
    private JButton applyBtn;
    private JLabel statusLabel;
    private JProgressBar progressBar;

    public interface ConsoleAppender {
        void append(String text);
        void appendLines(List<String> lines);
    }

    public RemoveCommentsDialog(JFrame parent, File projectRoot, ConsoleAppender consoleAppender) {
        super(parent, "Limpiar Comentarios", true);
        this.projectRoot = projectRoot;
        this.consoleAppender = consoleAppender;
        
        setSize(650, 550);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        
        setupUI();
        setupListeners();
    }

    private void setupUI() {
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        JLabel titleLabel = new JLabel("🧹 Eliminar Comentarios del Código");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        mainPanel.add(titleLabel, BorderLayout.NORTH);
        
        JPanel configPanel = new JPanel(new GridBagLayout());
        configPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder("⚙️ Opciones de limpieza"),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;
        
        gbc.gridx = 0; gbc.gridy = 0;
        removeSingleLineCheck = new JCheckBox("Eliminar comentarios de una línea (// ...)", true);
        removeSingleLineCheck.setToolTipText("Elimina todo lo que esté después de //");
        configPanel.add(removeSingleLineCheck, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        removeMultiLineCheck = new JCheckBox("Eliminar comentarios en bloque (/* ... */)", true);
        removeMultiLineCheck.setToolTipText("Elimina bloques de comentarios multi-línea y Javadoc");
        configPanel.add(removeMultiLineCheck, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        JPanel warningPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel warning = new JLabel("⚠️");
        warning.setForeground(Color.ORANGE);
        warning.setFont(new Font("Segoe UI", Font.BOLD, 14));
        JLabel warningText = new JLabel("<html><font color='#AAAAAA'>Seguro: No eliminará // si están dentro de un String (ej: URLs).</font></html>");
        warningPanel.add(warning);
        warningPanel.add(warningText);
        configPanel.add(warningPanel, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        previewOnlyCheck = new JCheckBox("Solo vista previa (no modificar archivos)", true);
        configPanel.add(previewOnlyCheck, gbc);
        
        mainPanel.add(configPanel, BorderLayout.NORTH);
        
        JPanel previewPanel = new JPanel(new BorderLayout());
        previewPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder("👁️ Archivos afectados"),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        
        previewArea = new JTextArea();
        previewArea.setFont(new Font("Monospaced", Font.PLAIN, 11));
        previewArea.setEditable(false);
        previewArea.setText("Presiona 'Vista previa' para escanear comentarios...\n\n" +
            "Se analizarán todos los archivos .java excluyendo:\n" +
            "target, build, .git, etc.");
        
        JScrollPane scrollPane = new JScrollPane(previewArea);
        previewPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(previewPanel, BorderLayout.CENTER);
        
        JPanel bottomPanel = new JPanel(new BorderLayout(10, 10));
        progressBar = new JProgressBar();
        progressBar.setVisible(false);
        progressBar.setIndeterminate(true);
        bottomPanel.add(progressBar, BorderLayout.NORTH);
        
        JPanel statusButtonPanel = new JPanel(new BorderLayout());
        statusLabel = new JLabel("Listo");
        statusButtonPanel.add(statusLabel, BorderLayout.WEST);
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        
        previewBtn = new JButton("👁️ Vista previa");
        previewBtn.setFont(new Font("Segoe UI", Font.BOLD, 11));
        previewBtn.setPreferredSize(new Dimension(140, 32));
        
        applyBtn = new JButton("🧹 Limpiar todo");
        applyBtn.setFont(new Font("Segoe UI", Font.BOLD, 11));
        applyBtn.setEnabled(false);
        applyBtn.setPreferredSize(new Dimension(140, 32));
        
        JButton closeBtn = new JButton("✕ Cerrar");
        closeBtn.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        closeBtn.setPreferredSize(new Dimension(90, 32));
        closeBtn.addActionListener(e -> dispose());
        
        buttonPanel.add(previewBtn);
        buttonPanel.add(applyBtn);
        buttonPanel.add(closeBtn);
        
        statusButtonPanel.add(buttonPanel, BorderLayout.EAST);
        bottomPanel.add(statusButtonPanel, BorderLayout.SOUTH);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
    }

    private void setupListeners() {
        previewBtn.addActionListener(e -> execute(true));
        applyBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this,
                "⚠️ ¿Eliminar los comentarios permanentemente?\n\nEsta acción no se puede deshacer fácilmente.",
                "Confirmar", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (confirm == JOptionPane.YES_OPTION) execute(false);
        });
        
        previewOnlyCheck.addActionListener(e -> applyBtn.setEnabled(!previewOnlyCheck.isSelected()));
    }

    private void execute(boolean preview) {
        if (!removeSingleLineCheck.isSelected() && !removeMultiLineCheck.isSelected()) {
            JOptionPane.showMessageDialog(this, "⚠️ Selecciona al menos un tipo de comentario", "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        setUIBusy(true, "🔍 Escaneando...");
        
        new Thread(() -> {
            CommentRemover remover = new CommentRemover(projectRoot);
            List<RemovalResult> res = remover.processFiles(removeSingleLineCheck.isSelected(), removeMultiLineCheck.isSelected(), preview);
            
            SwingUtilities.invokeLater(() -> {
                showResults(res, preview);
                setUIBusy(false, null);
            });
        }).start();
    }

    private void showResults(List<RemovalResult> results, boolean wasPreview) {
        StringBuilder sb = new StringBuilder();
        if (results.isEmpty()) {
            sb.append("✅ No se encontraron comentarios para eliminar.\n¡Código limpio!");
            statusLabel.setText("✅ Sin comentarios encontrados");
            previewArea.setText(sb.toString());
            return;
        }

        int totalSingle = 0, totalMulti = 0, modified = 0;
        
        for (RemovalResult r : results) {
            if (r.hasError()) {
                sb.append("❌ ").append(r.getRelativePath(projectRoot)).append(" (Error)\n");
            } else {
                totalSingle += r.getSingleLineRemoved();
                totalMulti += r.getMultiLineRemoved();
                if (r.isModified()) modified++;
                
                sb.append("📄 ").append(r.getRelativePath(projectRoot)).append("\n");
                if (r.getSingleLineRemoved() > 0) sb.append("   └─ // Eliminados: ").append(r.getSingleLineRemoved()).append("\n");
                if (r.getMultiLineRemoved() > 0) sb.append("   └─ /**/ Eliminados: ").append(r.getMultiLineRemoved()).append("\n");
                sb.append("\n");
            }
        }
        
        sb.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
        sb.append("  📊 TOTAL: ").append(totalSingle + totalMulti).append(" comentarios en ").append(results.size()).append(" archivos\n");
        if (!wasPreview) sb.append("  ✅ Archivos modificados: ").append(modified).append("\n");
        sb.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
        
        previewArea.setText(sb.toString());
        previewArea.setCaretPosition(0);
        
        if (consoleAppender != null) {
            consoleAppender.append("═══════════════════════════════════════════════════════════");
            consoleAppender.append("🧹 Limpieza de comentarios: " + (totalSingle + totalMulti) + " eliminados");
            if (!wasPreview) consoleAppender.append("   ✅ " + modified + " archivos modificados");
            consoleAppender.append("═══════════════════════════════════════════════════════════");
        }
        
        statusLabel.setText(wasPreview ? "👁️ " + (totalSingle + totalMulti) + " encontrados" : "✅ " + modified + " archivos limpiados");
        applyBtn.setEnabled(!previewOnlyCheck.isSelected());
    }

    private void setUIBusy(boolean busy, String txt) {
        progressBar.setVisible(busy);
        previewBtn.setEnabled(!busy);
        applyBtn.setEnabled(!busy && !previewOnlyCheck.isSelected());
        removeSingleLineCheck.setEnabled(!busy);
        removeMultiLineCheck.setEnabled(!busy);
        previewOnlyCheck.setEnabled(!busy);
        if (txt != null) statusLabel.setText(txt);
    }
}