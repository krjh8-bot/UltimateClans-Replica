package org.krjh8.ui.dialogs;

import org.krjh8.refactor.ImportRefactorer;
import org.krjh8.refactor.ImportRefactorer.ImportMatch;
import org.krjh8.refactor.ImportRefactorer.RefactorResult;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.io.File;
import java.util.List;

public class RefactorImportsDialog extends JDialog {
    
    private final File projectRoot;
    private final ConsoleAppender consoleAppender;
    
    private JTextField oldPackageField;
    private JTextField newPackageField;
    private JCheckBox includeSubpackagesCheck;
    private JCheckBox previewOnlyCheck;
    private JTextArea previewArea;
    private JButton previewBtn;
    private JButton applyBtn;
    private JButton closeButton;
    private JLabel statusLabel;
    private JProgressBar progressBar;
    
    private String lastOldPackage = "";
    private String lastNewPackage = "";

    public interface ConsoleAppender {
        void append(String text);
        void appendLines(List<String> lines);
    }

    public RefactorImportsDialog(JFrame parent, File projectRoot, ConsoleAppender consoleAppender) {
        super(parent, "Refactor Imports & Paquetes", true);
        this.projectRoot = projectRoot;
        this.consoleAppender = consoleAppender;
        
        setSize(700, 600);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        
        setupUI();
        setupListeners();
    }

    private void setupUI() {
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        JLabel titleLabel = new JLabel("🔄 Refactorizar Imports en Masa");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        mainPanel.add(titleLabel, BorderLayout.NORTH);
        
        JPanel configPanel = new JPanel(new GridBagLayout());
        configPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder("⚙️ Configuración"),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0;
        configPanel.add(new JLabel("📦 Paquete anterior:"), gbc);
        
        gbc.gridx = 1; gbc.gridy = 0; gbc.weightx = 1;
        oldPackageField = new JTextField("com.ejemplo.viejo");
        oldPackageField.setFont(new Font("Monospaced", Font.PLAIN, 13));
        configPanel.add(oldPackageField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0;
        configPanel.add(new JLabel("📦 Paquete nuevo:"), gbc);
        
        gbc.gridx = 1; gbc.gridy = 1; gbc.weightx = 1;
        newPackageField = new JTextField("com.ejemplo.nuevo");
        newPackageField.setFont(new Font("Monospaced", Font.PLAIN, 13));
        configPanel.add(newPackageField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        JLabel arrowLabel = new JLabel("                ⬇️");
        arrowLabel.setHorizontalAlignment(SwingConstants.CENTER);
        configPanel.add(arrowLabel, gbc);
        
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        JLabel exampleLabel = new JLabel(
            "<html><font color='#AAAAAA'>Ejemplo: <code>import com.ejemplo.viejo.Clase;</code> → <code>import com.ejemplo.nuevo.Clase;</code></font></html>"
        );
        configPanel.add(exampleLabel, gbc);
        
        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        JPanel optionsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 0));
        
        includeSubpackagesCheck = new JCheckBox("Incluir subpaquetes", true);
        includeSubpackagesCheck.setToolTipText("Reemplaza también subpaquetes (com.old.pkg.sub → com.new.pkg.sub)");
        optionsPanel.add(includeSubpackagesCheck);
        
        previewOnlyCheck = new JCheckBox("Solo vista previa", true);
        previewOnlyCheck.setToolTipText("No modifica archivos, solo muestra qué cambiaría");
        optionsPanel.add(previewOnlyCheck);
        
        configPanel.add(optionsPanel, gbc);
        mainPanel.add(configPanel, BorderLayout.NORTH);
        
        JPanel previewPanel = new JPanel(new BorderLayout());
        previewPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder("👁️ Resultados"),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        
        previewArea = new JTextArea();
        previewArea.setFont(new Font("Monospaced", Font.PLAIN, 11));
        previewArea.setEditable(false);
        previewArea.setText("Presiona '👁️ Vista previa' para buscar imports y paquetes...\n\n" +
            "Se buscarán todos los archivos .java en el proyecto\n" +
            "(excluyendo carpetas: target, build, .git, etc.)");
        
        JScrollPane scrollPane = new JScrollPane(previewArea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        previewPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(previewPanel, BorderLayout.CENTER);
        
        JPanel bottomPanel = new JPanel(new BorderLayout(10, 10));
        
        progressBar = new JProgressBar();
        progressBar.setVisible(false);
        progressBar.setIndeterminate(true);
        bottomPanel.add(progressBar, BorderLayout.NORTH);
        
        JPanel statusButtonPanel = new JPanel(new BorderLayout());
        
        statusLabel = new JLabel("Listo");
        statusButtonPanel.add(statusLabel, BorderLayout.WEST);
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        
        previewBtn = new JButton("👁️ Vista previa");
        previewBtn.setFont(new Font("Segoe UI", Font.BOLD, 11));
        previewBtn.setPreferredSize(new Dimension(140, 32));
        
        applyBtn = new JButton("✅ Aplicar cambios");
        applyBtn.setFont(new Font("Segoe UI", Font.BOLD, 11));
        applyBtn.setEnabled(false);
        applyBtn.setPreferredSize(new Dimension(150, 32));
        
        closeButton = new JButton("✕ Cerrar");
        closeButton.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        closeButton.setPreferredSize(new Dimension(90, 32));
        
        buttonPanel.add(previewBtn);
        buttonPanel.add(applyBtn);
        buttonPanel.add(closeButton);
        
        statusButtonPanel.add(buttonPanel, BorderLayout.EAST);
        bottomPanel.add(statusButtonPanel, BorderLayout.SOUTH);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
    }

    private void setupListeners() {
        previewBtn.addActionListener(e -> executeRefactor(true));
        
        applyBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this,
                "⚠️ ¿Estás seguro de aplicar los cambios?\n\n" +
                "Esta acción modificará archivos del proyecto.\n" +
                "Se recomienda tener un respaldo o usar Git.",
                "Confirmar refactorización",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);
            
            if (confirm == JOptionPane.YES_OPTION) executeRefactor(false);
        });
        
        closeButton.addActionListener(e -> dispose());
        
        previewOnlyCheck.addActionListener(e -> {
            applyBtn.setEnabled(!previewOnlyCheck.isSelected() && !lastOldPackage.isEmpty());
        });
    }

    private void executeRefactor(boolean previewOnly) {
        String oldPackage = oldPackageField.getText().trim();
        String newPackage = newPackageField.getText().trim();
        
        if (oldPackage.isEmpty() || newPackage.isEmpty()) {
            JOptionPane.showMessageDialog(this, "⚠️ Debes completar ambos paquetes", "Validación", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (oldPackage.equals(newPackage)) {
            JOptionPane.showMessageDialog(this, "⚠️ Los paquetes son iguales", "Validación", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        lastOldPackage = oldPackage;
        lastNewPackage = newPackage;
        
        setUIBusy(true, previewOnly ? "🔍 Buscando..." : "🔄 Aplicando...");
        
        new Thread(() -> {
            ImportRefactorer refactorer = new ImportRefactorer(projectRoot);
            List<RefactorResult> results = refactorer.refactorImports(oldPackage, newPackage, includeSubpackagesCheck.isSelected(), previewOnly);
            
            SwingUtilities.invokeLater(() -> {
                displayResults(results, oldPackage, newPackage, previewOnly);
                setUIBusy(false, null);
            });
        }).start();
    }

    private void setUIBusy(boolean busy, String statusText) {
        progressBar.setVisible(busy);
        previewBtn.setEnabled(!busy);
        applyBtn.setEnabled(!busy && !previewOnlyCheck.isSelected() && !lastOldPackage.isEmpty());
        closeButton.setEnabled(!busy);
        oldPackageField.setEnabled(!busy);
        newPackageField.setEnabled(!busy);
        includeSubpackagesCheck.setEnabled(!busy);
        previewOnlyCheck.setEnabled(!busy);
        
        if (statusText != null) statusLabel.setText(statusText);
    }

    private void displayResults(List<RefactorResult> results, String oldPackage, String newPackage, boolean wasPreview) {
        StringBuilder sb = new StringBuilder();
        
        if (results.isEmpty()) {
            sb.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
            sb.append("  No se encontraron imports/packages que coincidan con:\n");
            sb.append("  ").append(oldPackage).append("\n");
            sb.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
            statusLabel.setText("✓ Sin resultados");
            previewArea.setText(sb.toString());
            return;
        }
        
        int totalImports = 0;
        int totalPackages = 0;
        int modifiedFiles = 0;
        
        sb.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
        sb.append("  REFACTOR: ").append(oldPackage).append("\n");
        sb.append("       →   ").append(newPackage).append("\n");
        sb.append("  MODO: ").append(wasPreview ? "👁️ Vista previa" : "✅ Cambios aplicados").append("\n");
        sb.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n");
        
        for (RefactorResult result : results) {
            if (result.hasError()) {
                sb.append("❌ ERROR: ").append(result.getRelativePath(projectRoot)).append("\n");
                sb.append("   └─ ").append(result.getError()).append("\n\n");
            } else {
                sb.append("📄 ").append(result.getRelativePath(projectRoot)).append("\n");
                
                if (result.getPackageMatch() != null) {
                    totalPackages++;
                    sb.append("   📦 PACKAGE:\n");
                    sb.append("   ┌─ ").append(result.getPackageMatch().oldStatement).append("\n");
                    sb.append("   └─ ").append(result.getPackageMatch().newStatement).append("\n");
                }
                
                if (result.getImportCount() > 0) {
                    sb.append("   📥 IMPORTS:\n");
                    for (ImportMatch imp : result.getFoundImports()) {
                        // ⭐ CORREGIDO: Usar variables públicas en lugar de getters
                        String staticPrefix = imp.isStatic ? "static " : "";
                        String suffix = imp.importPath.substring(oldPackage.length());
                        String newImportPath = newPackage + suffix;
                        
                        sb.append("   ┌─ ").append(imp.originalStatement).append("\n");
                        sb.append("   └─ import ").append(staticPrefix).append(newImportPath).append(";\n");
                    }
                    totalImports += result.getImportCount();
                }
                
                if (result.isModified()) {
                    sb.append("   ✅ MODIFICADO\n");
                    modifiedFiles++;
                } else if (wasPreview) {
                    sb.append("   🔍 Se modificaría\n");
                }
                sb.append("\n");
            }
        }
        
        sb.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
        sb.append("  📊 RESUMEN:\n");
        sb.append("     • Archivos afectados: ").append(results.size()).append("\n");
        sb.append("     • Packages cambiados: ").append(totalPackages).append("\n");
        sb.append("     • Imports cambiados:  ").append(totalImports).append("\n");
        if (!wasPreview) sb.append("     • Archivos modificados: ").append(modifiedFiles).append("\n");
        sb.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
        
        previewArea.setText(sb.toString());
        previewArea.setCaretPosition(0);
        
        if (consoleAppender != null) {
            consoleAppender.append("═══════════════════════════════════════════════════════════");
            consoleAppender.append("🔄 Refactor: " + oldPackage + " → " + newPackage);
            consoleAppender.append("   📦 Packages: " + totalPackages + " | 📥 Imports: " + totalImports);
            if (!wasPreview) consoleAppender.append("   ✅ " + modifiedFiles + " archivos modificados");
            consoleAppender.append("═══════════════════════════════════════════════════════════");
        }
        
        String statusText = wasPreview 
            ? "👁️ " + totalPackages + " pkg, " + totalImports + " imp en " + results.size() + " archivos"
            : "✅ " + modifiedFiles + " archivos modificados";
        statusLabel.setText(statusText);
        applyBtn.setEnabled(!previewOnlyCheck.isSelected() && results.size() > 0);
    }
}