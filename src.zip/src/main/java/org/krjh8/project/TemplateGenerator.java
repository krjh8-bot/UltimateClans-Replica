package org.krjh8.project;

public class TemplateGenerator {
    
    public static String getJavaClassTemplate(String className, String packageName) {
        return "package " + packageName + ";\n\n" +
               "/**\n" +
               " * Clase: " + className + "\n" +
               " */\n" +
               "public class " + className + " {\n" +
               "    \n" +
               "    public " + className + "() {\n" +
               "        // Constructor\n" +
               "    }\n" +
               "    \n" +
               "    public static void main(String[] args) {\n" +
               "        System.out.println(\"Hola desde " + className + "\");\n" +
               "    }\n" +
               "}\n";
    }
}