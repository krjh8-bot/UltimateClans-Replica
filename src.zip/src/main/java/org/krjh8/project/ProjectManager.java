package org.krjh8.project;

import org.krjh8.file.FileManager;
import java.io.File;

public class ProjectManager {
    private File currentProject;
    private String projectName;

    public boolean createNewProject(String path, String groupId, String artifactId, String version) {
        try {
            File projectDir = new File(path);
            
            if (!projectDir.exists()) {
                projectDir.mkdirs();
            }

            System.out.println("Creando proyecto en: " + projectDir.getAbsolutePath());

            File srcMain = new File(projectDir, "src");
            File srcMainJava = new File(srcMain, "main");
            File srcMainJavaDir = new File(srcMainJava, "java");
            File srcMainResources = new File(srcMainJava, "resources");
            
            File srcTest = new File(srcMain, "test");
            File srcTestJava = new File(srcTest, "java");
            File srcTestResources = new File(srcTest, "resources");

            srcMainJavaDir.mkdirs();
            srcMainResources.mkdirs();
            srcTestJava.mkdirs();
            srcTestResources.mkdirs();

            System.out.println("✓ Estructura de carpetas creada");

            String pomContent = generatePom(groupId, artifactId, version);
            File pomFile = new File(projectDir, "pom.xml");
            if (!FileManager.writeFile(pomFile, pomContent)) {
                System.err.println("No se pudo crear pom.xml");
                return false;
            }
            System.out.println("✓ pom.xml creado");

            String gitignore = "target/\n.idea/\n*.iml\n.DS_Store\n.classpath\n.project\n.settings/\n";
            if (!FileManager.writeFile(new File(projectDir, ".gitignore"), gitignore)) {
                System.err.println("No se pudo crear .gitignore");
            }
            System.out.println("✓ .gitignore creado");

            String readme = "# " + artifactId + "\n\nProyecto Maven creado con Java Plugin IDE\n\n" +
                           "## Compilar\n```bash\nmvn clean compile\n```\n\n" +
                           "## Construir JAR\n```bash\nmvn clean package\n```\n\n" +
                           "## Ejecutar tests\n```bash\nmvn test\n```\n";
            if (!FileManager.writeFile(new File(projectDir, "README.md"), readme)) {
                System.err.println("No se pudo crear README.md");
            }
            System.out.println("✓ README.md creado");

            String[] packageParts = groupId.split("\\.");
            
            File packageDir = srcMainJavaDir;
            for (String part : packageParts) {
                packageDir = new File(packageDir, part);
            }
            packageDir.mkdirs();
            
            String javaContent = generateJavaClass(groupId);
            File javaFile = new File(packageDir, "Main.java");
            if (!FileManager.writeFile(javaFile, javaContent)) {
                System.err.println("No se pudo crear Main.java");
            }
            System.out.println("✓ Main.java creado en: " + packageDir.getAbsolutePath());

            File testPackageDir = srcTestJava;
            for (String part : packageParts) {
                testPackageDir = new File(testPackageDir, part);
            }
            testPackageDir.mkdirs();
            
            String testContent = generateTestClass(groupId);
            File testFile = new File(testPackageDir, "MainTest.java");
            if (!FileManager.writeFile(testFile, testContent)) {
                System.err.println("No se pudo crear MainTest.java");
            }
            System.out.println("✓ MainTest.java creado en: " + testPackageDir.getAbsolutePath());

            currentProject = projectDir;
            projectName = artifactId;

            System.out.println("✓ Proyecto creado exitosamente!");
            return true;

        } catch (Exception e) {
            System.err.println("Error creando proyecto: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public boolean openProject(String projectPath) {
        try {
            File project = new File(projectPath);
            File pomFile = new File(project, "pom.xml");

            if (pomFile.exists() && pomFile.isFile()) {
                currentProject = project;
                projectName = project.getName();
                System.out.println("Proyecto abierto: " + projectName);
                return true;
            } else {
                System.err.println("pom.xml no encontrado en: " + projectPath);
                return false;
            }
        } catch (Exception e) {
            System.err.println("Error abriendo proyecto: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    private String generatePom(String groupId, String artifactId, String version) {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<project xmlns=\"http://maven.apache.org/POM/4.0.0\"\n" +
                "         xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n" +
                "         xsi:schemaLocation=\"http://maven.apache.org/POM/4.0.0\n" +
                "         http://maven.apache.org/xsd/maven-4.0.0.xsd\">\n" +
                "    <modelVersion>4.0.0</modelVersion>\n\n" +
                "    <groupId>" + groupId + "</groupId>\n" +
                "    <artifactId>" + artifactId + "</artifactId>\n" +
                "    <version>" + version + "</version>\n" +
                "    <packaging>jar</packaging>\n\n" +
                "    <name>" + artifactId + "</name>\n" +
                "    <description>Proyecto Maven creado con Java Plugin IDE</description>\n\n" +
                "    <properties>\n" +
                "        <maven.compiler.source>21</maven.compiler.source>\n" +
                "        <maven.compiler.target>21</maven.compiler.target>\n" +
                "        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>\n" +
                "    </properties>\n\n" +
                "    <dependencies>\n" +
                "        <dependency>\n" +
                "            <groupId>junit</groupId>\n" +
                "            <artifactId>junit</artifactId>\n" +
                "            <version>4.13.2</version>\n" +
                "            <scope>test</scope>\n" +
                "        </dependency>\n" +
                "    </dependencies>\n\n" +
                "    <build>\n" +
                "        <plugins>\n" +
                "            <plugin>\n" +
                "                <groupId>org.apache.maven.plugins</groupId>\n" +
                "                <artifactId>maven-compiler-plugin</artifactId>\n" +
                "                <version>3.11.0</version>\n" +
                "                <configuration>\n" +
                "                    <source>21</source>\n" +
                "                    <target>21</target>\n" +
                "                </configuration>\n" +
                "            </plugin>\n" +
                "            <plugin>\n" +
                "                <groupId>org.apache.maven.plugins</groupId>\n" +
                "                <artifactId>maven-jar-plugin</artifactId>\n" +
                "                <version>3.3.0</version>\n" +
                "                <configuration>\n" +
                "                    <archive>\n" +
                "                        <manifest>\n" +
                "                            <mainClass>" + groupId + ".Main</mainClass>\n" +
                "                        </manifest>\n" +
                "                    </archive>\n" +
                "                </configuration>\n" +
                "            </plugin>\n" +
                "        </plugins>\n" +
                "    </build>\n" +
                "</project>\n";
    }

    private String generateJavaClass(String packageName) {
        return "package " + packageName + ";\n\n" +
               "/**\n" +
               " * Clase principal del proyecto\n" +
               " */\n" +
               "public class Main {\n" +
               "    \n" +
               "    public static void main(String[] args) {\n" +
               "        System.out.println(\"¡Hola desde mi proyecto Maven!\");\n" +
               "    }\n" +
               "}\n";
    }

    private String generateTestClass(String packageName) {
        return "package " + packageName + ";\n\n" +
               "import org.junit.Test;\n" +
               "import static org.junit.Assert.*;\n\n" +
               "/**\n" +
               " * Tests unitarios\n" +
               " */\n" +
               "public class MainTest {\n" +
               "    \n" +
               "    @Test\n" +
               "    public void testExample() {\n" +
               "        assertTrue(true);\n" +
               "    }\n" +
               "}\n";
    }

    public File getCurrentProject() {
        return currentProject;
    }

    public String getProjectName() {
        return projectName != null ? projectName : "Sin proyecto";
    }

    public boolean hasProjectOpen() {
        return currentProject != null && currentProject.exists();
    }

    public void closeProject() {
        currentProject = null;
        projectName = null;
    }

    public String getCurrentProjectPath() {
        if (currentProject != null) {
            return currentProject.getAbsolutePath();
        }
        return null;
    }

    public boolean isValidMavenProject(File folder) {
        return folder != null && folder.isDirectory() && 
               new File(folder, "pom.xml").exists();
    }

    public File[] listProjectFiles() {
        if (currentProject != null) {
            return currentProject.listFiles();
        }
        return new File[0];
    }

    public File[] findJavaFiles(File directory) {
        if (directory == null || !directory.isDirectory()) {
            return new File[0];
        }

        return directory.listFiles((dir, name) -> {
            if (name.endsWith(".java")) {
                return true;
            }
            File file = new File(dir, name);
            if (file.isDirectory()) {
                return findJavaFiles(file).length > 0;
            }
            return false;
        });
    }

    public File getSourceDirectory() {
        if (currentProject != null) {
            return new File(currentProject, "src" + File.separator + "main" + File.separator + "java");
        }
        return null;
    }

    public File getTestDirectory() {
        if (currentProject != null) {
            return new File(currentProject, "src" + File.separator + "test" + File.separator + "java");
        }
        return null;
    }

    public File getTargetDirectory() {
        if (currentProject != null) {
            return new File(currentProject, "target");
        }
        return null;
    }

    public File getResourcesDirectory() {
        if (currentProject != null) {
            return new File(currentProject, "src" + File.separator + "main" + File.separator + "resources");
        }
        return null;
    }

    public File getTestResourcesDirectory() {
        if (currentProject != null) {
            return new File(currentProject, "src" + File.separator + "test" + File.separator + "resources");
        }
        return null;
    }

    public boolean createJavaFile(String packageName, String className) {
        try {
            File sourceDir = getSourceDirectory();
            if (sourceDir == null) {
                return false;
            }

            String[] packageParts = packageName.split("\\.");
            File packageDir = sourceDir;
            for (String part : packageParts) {
                packageDir = new File(packageDir, part);
            }
            packageDir.mkdirs();

            String content = generateJavaClass(packageName);
            File javaFile = new File(packageDir, className + ".java");
            
            return FileManager.writeFile(javaFile, content);
        } catch (Exception e) {
            System.err.println("Error creando archivo Java: " + e.getMessage());
            return false;
        }
    }

    public boolean createTestFile(String packageName, String testClassName) {
        try {
            File testDir = getTestDirectory();
            if (testDir == null) {
                return false;
            }

            String[] packageParts = packageName.split("\\.");
            File packageDir = testDir;
            for (String part : packageParts) {
                packageDir = new File(packageDir, part);
            }
            packageDir.mkdirs();

            String content = generateTestClass(packageName);
            File testFile = new File(packageDir, testClassName + ".java");
            
            return FileManager.writeFile(testFile, content);
        } catch (Exception e) {
            System.err.println("Error creando archivo de test: " + e.getMessage());
            return false;
        }
    }

    public boolean deleteFile(File file) {
        try {
            return FileManager.deleteFile(file);
        } catch (Exception e) {
            System.err.println("Error eliminando archivo: " + e.getMessage());
            return false;
        }
    }

    public void getAllFilesRecursive(File directory, java.util.List<File> fileList) {
        if (directory == null || !directory.isDirectory()) {
            return;
        }

        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isFile()) {
                    fileList.add(file);
                } else if (file.isDirectory() && !file.getName().equals("target")) {
                    getAllFilesRecursive(file, fileList);
                }
            }
        }
    }

    public java.util.List<File> findFilesByExtension(String extension) {
        java.util.List<File> files = new java.util.ArrayList<>();
        if (currentProject != null) {
            findFilesByExtensionRecursive(currentProject, extension, files);
        }
        return files;
    }

    private void findFilesByExtensionRecursive(File directory, String extension, java.util.List<File> fileList) {
        if (!directory.isDirectory()) {
            return;
        }

        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isFile() && file.getName().endsWith("." + extension)) {
                    fileList.add(file);
                } else if (file.isDirectory() && !file.getName().equals("target") && !file.getName().equals(".idea")) {
                    findFilesByExtensionRecursive(file, extension, fileList);
                }
            }
        }
    }
}