package org.krjh8.config;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class EnvironmentDetector {

    public static boolean validateEnvironment() {
        return isJavaInstalled() && isMavenInstalled();
    }

    public static String getJavaPath() {
        return System.getProperty("java.home");
    }

    public static String getMavenPath() {
        try {
            Process process = new ProcessBuilder("cmd", "/c", "mvn -v")
                    .redirectErrorStream(true)
                    .start();

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream())
            );

            String line;
            while ((line = reader.readLine()) != null) {
                if (line.toLowerCase().contains("apache maven")) {
                    return "mvn";
                }
            }

            process.waitFor();
        } catch (Exception e) {
            return null;
        }
        return null;
    }

    private static boolean isJavaInstalled() {
        try {
            Process process = new ProcessBuilder("cmd", "/c", "java -version")
                    .redirectErrorStream(true)
                    .start();

            return process.waitFor() == 0;
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean isMavenInstalled() {
        return getMavenPath() != null;
    }

    public static String getJavaVersion() {
        return System.getProperty("java.version");
    }
}
