package org.krjh8.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class Configuration {
    private static final String CONFIG_DIR = System.getProperty("user.home") 
        + File.separator + ".pluginide";
    private static final String CONFIG_FILE = CONFIG_DIR + File.separator + "config.json";
    private static Configuration instance;
    private Map<String, String> settings;
    private Gson gson;

    private Configuration() {
        gson = new GsonBuilder().setPrettyPrinting().create();
        loadConfiguration();
    }

    public static Configuration getInstance() {
        if (instance == null) {
            instance = new Configuration();
        }
        return instance;
    }

    private void loadConfiguration() {
        try {
            if (Files.exists(Paths.get(CONFIG_FILE))) {
                String json = new String(Files.readAllBytes(Paths.get(CONFIG_FILE)));
                settings = gson.fromJson(json, Map.class);
            } else {
                settings = new HashMap<>();
                createDefaultConfig();
            }
        } catch (IOException e) {
            settings = new HashMap<>();
            createDefaultConfig();
        }
    }

    private void createDefaultConfig() {
        settings.put("theme", "dark");
        settings.put("fontSize", "12");
        settings.put("autoSave", "true");
        settings.put("javaPath", EnvironmentDetector.getJavaPath());
        settings.put("mavenPath", EnvironmentDetector.getMavenPath());
        saveConfiguration();
    }

    public void saveConfiguration() {
        try {
            Files.createDirectories(Paths.get(CONFIG_DIR));
            String json = gson.toJson(settings);
            Files.write(Paths.get(CONFIG_FILE), json.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String getSetting(String key) {
        return settings.getOrDefault(key, "");
    }

    public void setSetting(String key, String value) {
        settings.put(key, value);
        saveConfiguration();
    }

    public Map<String, String> getAllSettings() {
        return new HashMap<>(settings);
    }
}