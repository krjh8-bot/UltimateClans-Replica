package org.krjh8.file;

import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;

public class FileManager {

    public static String readFile(File file) {
        try {
            if (!file.exists()) {
                return "";
            }
            return new String(Files.readAllBytes(file.toPath()));
        } catch (Exception e) {
            System.err.println("Error leyendo archivo: " + file.getName());
            e.printStackTrace();
            return "";
        }
    }
    
    public static boolean writeFile(File file, String content) {
        try {
            File parentDir = file.getParentFile();
            
            if (parentDir != null && !parentDir.exists()) {
                if (!parentDir.mkdirs()) {
                    System.err.println("No se pudo crear directorio: " + parentDir.getAbsolutePath());
                    return false;
                }
            }
            
            if (file.exists() && file.isDirectory()) {
                System.err.println("El archivo ya existe como directorio: " + file.getAbsolutePath());
                return false;
            }
            
            try (FileWriter writer = new FileWriter(file)) {
                writer.write(content);
            }
            return true;
        } catch (Exception e) {
            System.err.println("Error escribiendo archivo: " + file.getAbsolutePath());
            e.printStackTrace();
            return false;
        }
    }
    
    public static boolean deleteFile(File file) {
        try {
            if (file.isDirectory()) {
                File[] files = file.listFiles();
                if (files != null) {
                    for (File f : files) {
                        deleteFile(f);
                    }
                }
            }
            return file.delete();
        } catch (Exception e) {
            System.err.println("Error eliminando archivo: " + file.getName());
            return false;
        }
    }
    
    public static boolean copyFile(File source, File destination) {
        try {
            if (destination.getParentFile() != null) {
                destination.getParentFile().mkdirs();
            }
            Files.copy(source.toPath(), destination.toPath());
            return true;
        } catch (Exception e) {
            System.err.println("Error copiando archivo");
            e.printStackTrace();
            return false;
        }
    }
    
    public static boolean exists(File file) {
        return file != null && file.exists();
    }
    
    public static String getFileExtension(File file) {
        String name = file.getName();
        int lastIndexOf = name.lastIndexOf(".");
        if (lastIndexOf == -1) {
            return "";
        }
        return name.substring(lastIndexOf + 1);
    }
    
    public static long getFileSize(File file) {
        if (file.exists() && file.isFile()) {
            return file.length();
        }
        return 0;
    }
    
    public static long getFileSizeKB(File file) {
        return getFileSize(file) / 1024;
    }
    
    public static boolean createDirectory(File directory) {
        try {
            return directory.mkdirs();
        } catch (Exception e) {
            System.err.println("Error creando directorio: " + directory.getAbsolutePath());
            return false;
        }
    }
    
    public static boolean renameFile(File oldFile, String newName) {
        try {
            File newFile = new File(oldFile.getParent(), newName);
            return oldFile.renameTo(newFile);
        } catch (Exception e) {
            System.err.println("Error renombrando archivo");
            return false;
        }
    }
}