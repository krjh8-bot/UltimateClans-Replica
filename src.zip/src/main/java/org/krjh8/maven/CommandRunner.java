package org.krjh8.maven;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class CommandRunner {
    private List<String> output;
    private List<String> errors;
    private int exitCode;
    private List<LogListener> logListeners;

    public interface LogListener {
        void onLogLine(String line, boolean isError);
    }

    public CommandRunner() {
        output = new CopyOnWriteArrayList<>();
        errors = new CopyOnWriteArrayList<>();
        exitCode = -1;
        logListeners = new ArrayList<>();
    }
    
    public void addLogListener(LogListener listener) {
        logListeners.add(listener);
    }

    private void notifyLogLine(String line, boolean isError) {
        for (LogListener listener : logListeners) {
            listener.onLogLine(line, isError);
        }
    }

    public int execute(String command) {
        output.clear();
        errors.clear();

        try {
            String[] cmd;
            String osName = System.getProperty("os.name").toLowerCase();
            
            if (osName.contains("win")) {
                cmd = new String[]{"cmd.exe", "/c", command};
            } else {
                cmd = new String[]{"bash", "-c", command};
            }
            
            ProcessBuilder pb = new ProcessBuilder(cmd);
            pb.redirectErrorStream(false);
            Process process = pb.start();

            Thread outputThread = new Thread(() -> {
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(process.getInputStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        output.add(line);
                        notifyLogLine(line, false);
                    }
                } catch (Exception e) {
                    String errorMsg = "Error leyendo salida: " + e.getMessage();
                    errors.add(errorMsg);
                    notifyLogLine(errorMsg, true);
                }
            });

            Thread errorThread = new Thread(() -> {
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(process.getErrorStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        errors.add(line);
                        notifyLogLine(line, true);
                    }
                } catch (Exception e) {
                    String errorMsg = "Error leyendo errores: " + e.getMessage();
                    errors.add(errorMsg);
                    notifyLogLine(errorMsg, true);
                }
            });

            outputThread.start();
            errorThread.start();

            exitCode = process.waitFor();

            outputThread.join();
            errorThread.join();

            return exitCode;

        } catch (Exception e) {
            exitCode = -1;
            String errorMsg = "Error ejecutando comando: " + e.getClass().getSimpleName() + " - " + e.getMessage();
            errors.add(errorMsg);
            notifyLogLine(errorMsg, true);
            e.printStackTrace();
            return -1;
        }
    }

    public List<String> getOutput() {
        return new ArrayList<>(output);
    }

    public List<String> getErrors() {
        return new ArrayList<>(errors);
    }

    public String getFullOutput() {
        return String.join("\n", output);
    }

    public String getFullErrors() {
        return String.join("\n", errors);
    }

    public int getExitCode() {
        return exitCode;
    }
}