package org.krjh8.maven;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MavenExecutor {
    private File projectPath;
    private CommandRunner runner;
    private List<String> lastOutput;
    private List<String> lastErrors;

    public MavenExecutor(File projectPath) {
        this.projectPath = projectPath;
        this.runner = new CommandRunner();
    }

    public boolean compile() {
        String command = "cd \"" + projectPath.getAbsolutePath() + "\" && mvn clean compile";
        int exitCode = runner.execute(command);
        lastOutput = runner.getOutput();
        lastErrors = runner.getErrors();
        return exitCode == 0;
    }

    public boolean buildJar() {
        String command = "cd \"" + projectPath.getAbsolutePath() + "\" && mvn clean package";
        int exitCode = runner.execute(command);
        lastOutput = runner.getOutput();
        lastErrors = runner.getErrors();
        return exitCode == 0;
    }

    public boolean runTests() {
        String command = "cd \"" + projectPath.getAbsolutePath() + "\" && mvn test";
        int exitCode = runner.execute(command);
        lastOutput = runner.getOutput();
        lastErrors = runner.getErrors();
        return exitCode == 0;
    }

    public boolean clean() {
        String command = "cd \"" + projectPath.getAbsolutePath() + "\" && mvn clean";
        int exitCode = runner.execute(command);
        lastOutput = runner.getOutput();
        lastErrors = runner.getErrors();
        return exitCode == 0;
    }

    public boolean install() {
        String command = "cd \"" + projectPath.getAbsolutePath() + "\" && mvn install";
        int exitCode = runner.execute(command);
        lastOutput = runner.getOutput();
        lastErrors = runner.getErrors();
        return exitCode == 0;
    }

    public List<String> getOutput() {
        return lastOutput != null ? lastOutput : new ArrayList<>();
    }

    public List<String> getErrors() {
        return lastErrors != null ? lastErrors : new ArrayList<>();
    }

    public String getLastOutput() {
        return runner.getFullOutput();
    }

    public String getLastErrors() {
        return runner.getFullErrors();
    }

    public void setCommandRunner(CommandRunner runner) {
        this.runner = runner;
    }

    public int getLastExitCode() {
        return runner.getExitCode();
    }
}