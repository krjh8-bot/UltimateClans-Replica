package org.krjh8.refactor;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ImportRefactorer {
    private static final Logger LOGGER = Logger.getLogger(ImportRefactorer.class.getName());
    
    private final File projectRoot;
    private final List<RefactorResult> results;
    
    private static final Set<String> IGNORED_FOLDERS = Set.of(
        "target", "build", ".git", "node_modules", ".idea", ".settings", "bin", ".mvn"
    );

    public ImportRefactorer(File projectRoot) {
        this.projectRoot = projectRoot;
        this.results = new ArrayList<>();
    }

    public List<RefactorResult> refactorImports(
            String oldBasePackage, 
            String newBasePackage,
            boolean includeSubpackages,
            boolean previewOnly) {
        
        results.clear();
        
        if (oldBasePackage == null || oldBasePackage.trim().isEmpty() ||
            newBasePackage == null || newBasePackage.trim().isEmpty()) {
            return results;
        }
        
        oldBasePackage = oldBasePackage.trim();
        newBasePackage = newBasePackage.trim();
        
        List<File> javaFiles = findJavaFiles(projectRoot);
        LOGGER.info("Encontrados " + javaFiles.size() + " archivos Java para analizar");
        
        for (File file : javaFiles) {
            refactorFile(file, oldBasePackage, newBasePackage, includeSubpackages, previewOnly);
        }
        
        return results;
    }

    private void refactorFile(File file, String oldBasePackage, String newBasePackage,
            boolean includeSubpackages, boolean previewOnly) {
        
        try {
            String content = Files.readString(file.toPath());
            
            List<ImportMatch> foundImports = findImports(content, oldBasePackage, includeSubpackages);
            
            // ⭐ CORREGIDO: Se le pasa newBasePackage
            PackageMatch packageMatch = findPackageDeclaration(content, oldBasePackage, newBasePackage, includeSubpackages);
            
            if (foundImports.isEmpty() && packageMatch == null) {
                return;
            }
            
            String newContent = content;
            
            if (packageMatch != null) {
                newContent = newContent.replace(packageMatch.oldStatement, packageMatch.newStatement);
            }
            
            newContent = replaceImports(newContent, foundImports, oldBasePackage, newBasePackage);
            
            boolean modified = false;
            if (!previewOnly && !newContent.equals(content)) {
                Files.writeString(file.toPath(), newContent);
                modified = true;
                LOGGER.info("Modificado: " + file.getAbsolutePath());
            }
            
            results.add(new RefactorResult(file, foundImports, packageMatch, modified, null));
            
        } catch (IOException e) {
            LOGGER.warning("Error procesando " + file.getName() + ": " + e.getMessage());
            results.add(new RefactorResult(file, Collections.emptyList(), null, false, e.getMessage()));
        }
    }

    // ⭐ CORREGIDO: Recibe newBasePackage como parámetro
    private PackageMatch findPackageDeclaration(String content, String basePackage, String newBasePackage, boolean includeSubpackages) {
        String escapedPackage = Pattern.quote(basePackage);
        String pattern;
        
        if (includeSubpackages) {
            pattern = "^package\\s+" + escapedPackage + "(\\.[A-Za-z0-9_$]+)*\\s*;";
        } else {
            pattern = "^package\\s+" + escapedPackage + "\\s*;";
        }
        
        Pattern regex = Pattern.compile(pattern, Pattern.MULTILINE);
        Matcher matcher = regex.matcher(content);
        
        if (matcher.find()) {
            String oldStatement = matcher.group();
            String importPath = oldStatement.replace("package ", "").replace(";", "").trim();
            String suffix = importPath.substring(basePackage.length());
            String newPath = newBasePackage + suffix;
            String newStatement = "package " + newPath + ";";
            
            return new PackageMatch(oldStatement, newStatement);
        }
        return null;
    }

    private List<ImportMatch> findImports(String content, String basePackage, boolean includeSubpackages) {
        List<ImportMatch> found = new ArrayList<>();
        
        String staticKeyword = "(static\\s+)?";
        String escapedPackage = Pattern.quote(basePackage);
        
        String pattern;
        if (includeSubpackages) {
            pattern = "import\\s+" + staticKeyword + escapedPackage + "(\\.[A-Za-z0-9_$]+)+\\s*;";
        } else {
            pattern = "import\\s+" + staticKeyword + escapedPackage + "\\.[A-Za-z0-9_$]+\\s*;";
        }
        
        Pattern regex = Pattern.compile(pattern);
        Matcher matcher = regex.matcher(content);
        
        while (matcher.find()) {
            String oldImport = matcher.group();
            String importPath = oldImport.replaceAll("^import\\s+(static\\s+)?", "").replace(";", "").trim();
            boolean isStatic = oldImport.contains("static");
            found.add(new ImportMatch(oldImport, importPath, isStatic));
        }
        
        return found;
    }

    private String replaceImports(String content, List<ImportMatch> foundImports, String oldBasePackage, String newBasePackage) {
        String newContent = content;
        for (ImportMatch match : foundImports) {
            String suffix = match.importPath.substring(oldBasePackage.length());
            String newImportPath = newBasePackage + suffix;
            String newStatement = match.isStatic ? "import static " + newImportPath + ";" : "import " + newImportPath + ";";
            newContent = newContent.replace(match.originalStatement, newStatement);
        }
        return newContent;
    }

    private List<File> findJavaFiles(File directory) {
        List<File> files = new ArrayList<>();
        findJavaFilesRecursive(directory, files);
        return files;
    }

    private void findJavaFilesRecursive(File directory, List<File> files) {
        File[] children = directory.listFiles();
        if (children == null) return;
        for (File child : children) {
            if (child.isDirectory()) {
                if (!IGNORED_FOLDERS.contains(child.getName())) findJavaFilesRecursive(child, files);
            } else if (child.getName().endsWith(".java")) {
                files.add(child);
            }
        }
    }

    // --- Clases internas de datos ---
    
    public static class ImportMatch {
        public final String originalStatement;
        public final String importPath;
        public final boolean isStatic;
        public ImportMatch(String originalStatement, String importPath, boolean isStatic) {
            this.originalStatement = originalStatement; this.importPath = importPath; this.isStatic = isStatic;
        }
    }

    public static class PackageMatch {
        public final String oldStatement;
        public final String newStatement;
        public PackageMatch(String oldStatement, String newStatement) {
            this.oldStatement = oldStatement; this.newStatement = newStatement;
        }
    }

    public static class RefactorResult {
        private final File file;
        private final List<ImportMatch> foundImports;
        private final PackageMatch packageMatch; 
        private final boolean modified;
        private final String error;
        
        public RefactorResult(File file, List<ImportMatch> foundImports, PackageMatch packageMatch, boolean modified, String error) {
            this.file = file; this.foundImports = foundImports; this.packageMatch = packageMatch; this.modified = modified; this.error = error;
        }
        
        public File getFile() { return file; }
        public List<ImportMatch> getFoundImports() { return foundImports; }
        public PackageMatch getPackageMatch() { return packageMatch; } 
        public boolean isModified() { return modified; }
        public String getError() { return error; }
        public boolean hasError() { return error != null; }
        public int getImportCount() { return foundImports.size(); }
        public String getRelativePath(File projectRoot) { return projectRoot.toPath().relativize(file.toPath()).toString(); }
    }
}