package org.krjh8.refactor;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

public class CommentRemover {
    private static final Logger LOGGER = Logger.getLogger(CommentRemover.class.getName());
    
    private final File projectRoot;
    private final List<RemovalResult> results;

    private static final Set<String> IGNORED_FOLDERS = Set.of(
        "target", "build", ".git", "node_modules", ".idea", ".settings", "bin", ".mvn"
    );

    public CommentRemover(File projectRoot) {
        this.projectRoot = projectRoot;
        this.results = new ArrayList<>();
    }

    public List<RemovalResult> processFiles(boolean removeSingleLine, boolean removeMultiLine, boolean previewOnly) {
        results.clear();
        List<File> javaFiles = findJavaFiles(projectRoot);
        LOGGER.info("Buscando comentarios en " + javaFiles.size() + " archivos...");

        for (File file : javaFiles) {
            processFile(file, removeSingleLine, removeMultiLine, previewOnly);
        }
        return results;
    }

    private void processFile(File file, boolean removeSingleLine, boolean removeMultiLine, boolean previewOnly) {
        try {
            String content = Files.readString(file.toPath());
            
            // Analizar el archivo
            AnalysisResult analysis = analyzeCode(content, removeSingleLine, removeMultiLine);
            
            if (analysis.totalRemoved > 0) {
                boolean modified = false;
                if (!previewOnly) {
                    Files.writeString(file.toPath(), analysis.newContent);
                    modified = true;
                    LOGGER.info("Comentarios eliminados de: " + file.getName());
                }
                results.add(new RemovalResult(file, analysis.singleLineCount, analysis.multiLineCount, modified, null));
            }
        } catch (IOException e) {
            LOGGER.warning("Error procesando " + file.getName() + ": " + e.getMessage());
            results.add(new RemovalResult(file, 0, 0, false, e.getMessage()));
        }
    }

    // ⭐ MOTOR PRINCIPAL: Analiza carácter por carácter para no romper Strings
    private AnalysisResult analyzeCode(String code, boolean removeSingle, boolean removeMulti) {
        StringBuilder newCode = new StringBuilder();
        int singleCount = 0;
        int multiCount = 0;
        int totalRemoved = 0;

        int length = code.length();
        int i = 0;

        while (i < length) {
            char c = code.charAt(i);

            // 1. Detectar Strings ("...")
            if (c == '"') {
                newCode.append(c);
                i++;
                while (i < length && code.charAt(i) != '"') {
                    if (code.charAt(i) == '\\') { // Ignorar escapes \"
                        newCode.append(code.charAt(i));
                        i++;
                    }
                    if (i < length) {
                        newCode.append(code.charAt(i));
                        i++;
                    }
                }
                if (i < length) {
                    newCode.append(code.charAt(i)); // Cerrar comilla
                    i++;
                }
                continue;
            }

            // 2. Detectar Char ('...')
            if (c == '\'') {
                newCode.append(c);
                i++;
                while (i < length && code.charAt(i) != '\'') {
                    if (code.charAt(i) == '\\') {
                        newCode.append(code.charAt(i));
                        i++;
                    }
                    if (i < length) {
                        newCode.append(code.charAt(i));
                        i++;
                    }
                }
                if (i < length) {
                    newCode.append(code.charAt(i));
                    i++;
                }
                continue;
            }

            // 3. Detectar Comentario de una línea (//)
            if (c == '/' && i + 1 < length && code.charAt(i + 1) == '/') {
                if (removeSingle) {
                    singleCount++;
                    i += 2;
                    while (i < length && code.charAt(i) != '\n') {
                        i++; // Saltar el comentario
                    }
                    totalRemoved++;
                } else {
                    newCode.append(c).append(code.charAt(i + 1));
                    i += 2;
                }
                continue;
            }

            // 4. Detectar Comentario Multi-línea (/* ... */)
            if (c == '/' && i + 1 < length && code.charAt(i + 1) == '*') {
                if (removeMulti) {
                    multiCount++;
                    i += 2;
                    while (i < length && !(code.charAt(i) == '*' && i + 1 < length && code.charAt(i + 1) == '/')) {
                        // Mantener los saltos de línea para no desordenar las líneas de código
                        if (code.charAt(i) == '\n') {
                            newCode.append('\n');
                        }
                        i++;
                    }
                    if (i < length) {
                        i += 2; // Saltar el cierre */
                    }
                    totalRemoved++;
                } else {
                    newCode.append(c).append(code.charAt(i + 1));
                    i += 2;
                }
                continue;
            }

            // 5. Cualquier otro carácter normal
            newCode.append(c);
            i++;
        }

        return new AnalysisResult(newCode.toString(), singleCount, multiCount, totalRemoved);
    }

    private List<File> findJavaFiles(File directory) {
        List<File> files = new ArrayList<>();
        findJavaFilesRecursive(directory, files);
        return files;
    }

    private void findJavaFilesRecursive(File directory, List<File> files) {
        File[] children = directory.listFiles();
        if (children == null) return;
        for (File child : children) {
            if (child.isDirectory()) {
                if (!IGNORED_FOLDERS.contains(child.getName())) findJavaFilesRecursive(child, files);
            } else if (child.getName().endsWith(".java")) {
                files.add(child);
            }
        }
    }

    // --- Clases de datos ---
    private static class AnalysisResult {
        String newContent;
        int singleLineCount;
        int multiLineCount;
        int totalRemoved;
        AnalysisResult(String newContent, int singleLineCount, int multiLineCount, int totalRemoved) {
            this.newContent = newContent; this.singleLineCount = singleLineCount; this.multiLineCount = multiLineCount; this.totalRemoved = totalRemoved;
        }
    }

    public static class RemovalResult {
        private final File file;
        private final int singleLineRemoved;
        private final int multiLineRemoved;
        private final boolean modified;
        private final String error;

        public RemovalResult(File file, int singleLineRemoved, int multiLineRemoved, boolean modified, String error) {
            this.file = file; this.singleLineRemoved = singleLineRemoved; this.multiLineRemoved = multiLineRemoved; this.modified = modified; this.error = error;
        }

        public File getFile() { return file; }
        public int getSingleLineRemoved() { return singleLineRemoved; }
        public int getMultiLineRemoved() { return multiLineRemoved; }
        public int getTotalRemoved() { return singleLineRemoved + multiLineRemoved; }
        public boolean isModified() { return modified; }
        public String getError() { return error; }
        public boolean hasError() { return error != null; }
        public String getRelativePath(File root) { return root.toPath().relativize(file.toPath()).toString(); }
    }
}