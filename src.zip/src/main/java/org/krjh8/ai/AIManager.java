package org.krjh8.ai;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AIManager {
    private static final Logger LOGGER = Logger.getLogger(AIManager.class.getName());
    private static final String OPENAI_API_URL = "https://api.openai.com/v1/chat/completions";
    
    private static final String API_KEY = "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";
    private static final String MODEL = "gpt-5.4-mini";
    
    private static final int TIMEOUT_MS = 30000;

    private Gson gson;

    public AIManager() {
        this.gson = new Gson();
        LOGGER.info("AIManager iniciado");
    }

    public String sendPrompt(String userMessage) throws IOException, IllegalArgumentException {
        if (userMessage == null || userMessage.trim().isEmpty()) {
            throw new IllegalArgumentException("El mensaje no puede estar vacío");
        }

        try {
            String systemPrompt = buildSystemPrompt();
            String requestBody = buildRequestBody(systemPrompt, userMessage);

            LOGGER.info("Enviando solicitud a OpenAI...");
            String response = sendHttpRequest(requestBody);
            LOGGER.info("Respuesta recibida");
            
            return extractContent(response);

        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Error en la comunicación con OpenAI: " + e.getMessage(), e);
            throw e;
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error procesando respuesta de OpenAI: " + e.getMessage(), e);
            throw new IOException("Error procesando respuesta: " + e.getMessage(), e);
        }
    }

    private String buildSystemPrompt() {
        return "You are a Java Bukkit Plugin development assistant for Minecraft. Your job is to help create and modify Minecraft plugin commands and classes.\n\n" +

                "IMPORTANT RULES:\n" +
                "1. ALWAYS respond with ONLY a valid JSON object. No explanations, no markdown, no extra text.\n" +
                "2. When user asks to CREATE or MODIFY a command, you MUST generate create_file and/or modify_file actions.\n" +
                "3. NEVER use read_file action unless explicitly asked to read something.\n" +
                "4. ALWAYS respond with valid JSON that can be parsed.\n\n" +

                "JSON format (REQUIRED):\n" +
                "{\n" +
                "  \"actions\": [\n" +
                "    {\n" +
                "      \"type\": \"create_file\",\n" +
                "      \"path\": \"src/main/java/org/krjh8/srooms/CommandName.java\",\n" +
                "      \"content\": \"package org.krjh8.srooms;\\n\\nimport org.bukkit.command.Command;\\n// ... full Java code here\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"type\": \"modify_file\",\n" +
                "      \"path\": \"src/main/java/org/krjh8/srooms/SRooms.java\",\n" +
                "      \"content\": \"package org.krjh8.srooms;\\n\\n// ... updated Java code here\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"type\": \"modify_file\",\n" +
                "      \"path\": \"src/main/resources/plugin.yml\",\n" +
                "      \"content\": \"name: sRooms\\nversion: 1.0.0\\n// ... yaml here\"\n" +
                "    }\n" +
                "  ]\n" +
                "}\n\n" +

                "BUKKIT PLUGIN GUIDELINES:\n" +
                "- All command classes must implement CommandExecutor\n" +
                "- Register commands in the main plugin class\n" +
                "- Update plugin.yml with new commands\n" +
                "- Use Bukkit API for effects, particles, teleportation, etc.\n" +
                "- GroupId: org.krjh8, ArtifactId: sRooms, Version: 1.0.0\n\n" +

                "EXAMPLE - Create /hola command that says Hola:\n" +
                "User: \"create a command /hola that says Hola in minecraft\"\n" +
                "Response:\n" +
                "{\n" +
                "  \"actions\": [\n" +
                "    {\n" +
                "      \"type\": \"create_file\",\n" +
                "      \"path\": \"src/main/java/org/krjh8/srooms/HolaCommand.java\",\n" +
                "      \"content\": \"package org.krjh8.srooms;\\n\\nimport org.bukkit.command.*;\\nimport org.bukkit.entity.Player;\\n\\npublic class HolaCommand implements CommandExecutor {\\n    @Override\\n    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {\\n        if (!(sender instanceof Player)) {\\n            sender.sendMessage(\\\"Solo jugadores pueden usar esto\\\");\\n            return true;\\n        }\\n        Player player = (Player) sender;\\n        player.sendMessage(\\\"¡Hola!\\\");\\n        return true;\\n    }\\n}\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"type\": \"modify_file\",\n" +
                "      \"path\": \"src/main/java/org/krjh8/srooms/SRooms.java\",\n" +
                "      \"content\": \"package org.krjh8.srooms;\\n\\nimport org.bukkit.plugin.java.JavaPlugin;\\n\\npublic class SRooms extends JavaPlugin {\\n    @Override\\n    public void onEnable() {\\n        getCommand(\\\"hola\\\").setExecutor(new HolaCommand());\\n    }\\n}\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"type\": \"modify_file\",\n" +
                "      \"path\": \"src/main/resources/plugin.yml\",\n" +
                "      \"content\": \"name: sRooms\\nversion: 1.0.0\\nmain: org.krjh8.srooms.SRooms\\ncommands:\\n  hola:\\n    description: Dice hola\\n    usage: /hola\"\n" +
                "    }\n" +
                "  ]\n" +
                "}\n\n" +

                "REMEMBER:\n" +
                "- ALWAYS return valid JSON, nothing else\n" +
                "- When creating commands, ALWAYS update SRooms.java and plugin.yml\n" +
                "- Use proper escaping for newlines (\\\\n) and quotes (\\\\\\\") in JSON strings\n" +
                "- NEVER read directories, ONLY create/modify files\n" +
                "- Each command needs: 1) CommandClass 2) Registration in SRooms.java 3) Entry in plugin.yml";
    }

    private String buildRequestBody(String systemPrompt, String userMessage) {
        JsonObject requestJson = new JsonObject();
        
        requestJson.addProperty("model", MODEL);
        requestJson.addProperty("temperature", 0.1);
        requestJson.addProperty("max_completion_tokens", 4000);

        com.google.gson.JsonArray messagesArray = new com.google.gson.JsonArray();

        JsonObject systemMessage = new JsonObject();
        systemMessage.addProperty("role", "system");
        systemMessage.addProperty("content", systemPrompt);
        messagesArray.add(systemMessage);

        JsonObject userMsg = new JsonObject();
        userMsg.addProperty("role", "user");
        userMsg.addProperty("content", userMessage);
        messagesArray.add(userMsg);

        requestJson.add("messages", messagesArray);

        return gson.toJson(requestJson);
    }
    
    private String sendHttpRequest(String requestBody) throws IOException {
        URL url = new URL(OPENAI_API_URL);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();

        connection.setRequestMethod("POST");
        connection.setRequestProperty("Content-Type", "application/json");
        connection.setRequestProperty("Authorization", "Bearer " + API_KEY);
        connection.setConnectTimeout(TIMEOUT_MS);
        connection.setReadTimeout(TIMEOUT_MS);
        connection.setDoOutput(true);

        try {
            try (OutputStream os = connection.getOutputStream()) {
                byte[] input = requestBody.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }

            int responseCode = connection.getResponseCode();
            if (responseCode != HttpURLConnection.HTTP_OK) {
                String errorMessage = readStream(connection.getErrorStream());
                throw new IOException("Error API (" + responseCode + "): " + errorMessage);
            }

            return readStream(connection.getInputStream());

        } finally {
            connection.disconnect();
        }
    }

    private String readStream(java.io.InputStream stream) throws IOException {
        if (stream == null) {
            return "";
        }

        StringBuilder result = new StringBuilder();
        try (Scanner scanner = new Scanner(stream, StandardCharsets.UTF_8)) {
            scanner.useDelimiter("\\A");
            if (scanner.hasNext()) {
                result.append(scanner.next());
            }
        }
        return result.toString();
    }

    private String extractContent(String responseJson) throws IOException {
        try {
            JsonObject response = gson.fromJson(responseJson, JsonObject.class);

            if (response == null) {
                throw new IOException("Respuesta JSON inválida");
            }

            com.google.gson.JsonArray choices = response.getAsJsonArray("choices");
            if (choices == null || choices.size() == 0) {
                throw new IOException("No hay choices en respuesta");
            }

            JsonObject firstChoice = choices.get(0).getAsJsonObject();
            JsonObject message = firstChoice.getAsJsonObject("message");

            if (message == null) {
                throw new IOException("No hay message en respuesta");
            }

            return message.get("content").getAsString();

        } catch (com.google.gson.JsonSyntaxException e) {
            throw new IOException("Error parseando JSON: " + e.getMessage(), e);
        }
    }

    public String getApiKeyMasked() {
        return "sk-..." + API_KEY.substring(Math.max(0, API_KEY.length() - 4));
    }

    public boolean isConfigured() {
        return true;
    }

    public String getModel() {
        return MODEL;
    }
}