package org.krjh8.ai;

import org.krjh8.util.PomXmlReader;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ActionExecutor {
    private static final Logger LOGGER = Logger.getLogger(ActionExecutor.class.getName());
    private File projectRoot;
    private PomXmlReader pomReader;
    private List<String> executionLog;

    public ActionExecutor(File projectRoot) {
        this.projectRoot = projectRoot;
        this.pomReader = new PomXmlReader(projectRoot);
        this.executionLog = new ArrayList<>();
    }

    public List<String> executeActions(List<AIAction> actions) {
        executionLog.clear();

        if (actions == null || actions.isEmpty()) {
            addLog("No hay acciones para ejecutar");
            return executionLog;
        }

        addLog("Ejecutando " + actions.size() + " acciones...\n");

        int successCount = 0;
        int errorCount = 0;

        for (int i = 0; i < actions.size(); i++) {
            AIAction action = actions.get(i);
            try {
                executeAction(action, i + 1);
                successCount++;
            } catch (Exception e) {
                addLog("❌ Error en acción #" + (i + 1) + ": " + e.getMessage());
                LOGGER.log(Level.WARNING, "Error ejecutando acción #" + (i + 1), e);
                errorCount++;
            }
        }

        addLog("\n" + "=".repeat(50));
        addLog("📊 Resumen: " + successCount + " exitosas, " + errorCount + " errores");
        addLog("=".repeat(50));

        return executionLog;
    }

    private void executeAction(AIAction action, int actionNumber) throws Exception {
        if (action == null) {
            throw new IllegalArgumentException("Acción nula");
        }

        if (!action.isValid()) {
            throw new IllegalArgumentException("Acción inválida: falta type o path");
        }

        String normalizedPath = normalizeAndValidatePath(action.path);

        switch (action.type.toLowerCase().trim()) {
            case "create_file":
                executeCreateFile(normalizedPath, action.content, actionNumber);
                break;

            case "modify_file":
                executeModifyFile(normalizedPath, action.content, actionNumber);
                break;

            case "delete_file":
                executeDeleteFile(normalizedPath, actionNumber);
                break;

            case "read_file":
                executeReadFile(normalizedPath, actionNumber);
                break;

            default:
                throw new IllegalArgumentException("Tipo de acción desconocido: '" + action.type + "'");
        }
    }
    
    private void executeCreateFile(String filePath, String content, int actionNumber) throws Exception {
        if (content == null || content.isEmpty()) {
            throw new IllegalArgumentException("El contenido del archivo no puede estar vacío");
        }

        Path path = Paths.get(projectRoot.getAbsolutePath(), filePath);

        if (Files.exists(path)) {
            addLog("⚠️ [" + actionNumber + "] Archivo ya existe: " + filePath);
            return;
        }

        try {
            Files.createDirectories(path.getParent());

            Files.writeString(path, content, StandardCharsets.UTF_8);

            addLog("✅ [" + actionNumber + "] Archivo creado: " + filePath);
            LOGGER.info("Archivo creado exitosamente: " + path.toAbsolutePath());

        } catch (Exception e) {
            throw new Exception("No se pudo crear archivo " + filePath + ": " + e.getMessage(), e);
        }
    }

    private void executeModifyFile(String filePath, String content, int actionNumber) throws Exception {
        if (content == null) {
            throw new IllegalArgumentException("El contenido del archivo no puede ser nulo");
        }

        Path path = Paths.get(projectRoot.getAbsolutePath(), filePath);

        try {
            if (!Files.exists(path)) {
                addLog("⚠️ [" + actionNumber + "] Archivo no existe, creando: " + filePath);
                Files.createDirectories(path.getParent());
            }

            Files.writeString(path, content, StandardCharsets.UTF_8);

            addLog("✅ [" + actionNumber + "] Archivo actualizado: " + filePath);
            LOGGER.info("Archivo modificado exitosamente: " + path.toAbsolutePath());

        } catch (Exception e) {
            throw new Exception("No se pudo modificar archivo " + filePath + ": " + e.getMessage(), e);
        }
    }

    private void executeDeleteFile(String filePath, int actionNumber) throws Exception {
        Path path = Paths.get(projectRoot.getAbsolutePath(), filePath);

        try {
            if (!Files.exists(path)) {
                addLog("⚠️ [" + actionNumber + "] Archivo no existe (no se elimina): " + filePath);
                return;
            }

            if (!Files.isRegularFile(path)) {
                throw new Exception("La ruta no es un archivo: " + filePath);
            }

            Files.delete(path);

            addLog("✅ [" + actionNumber + "] Archivo eliminado: " + filePath);
            LOGGER.info("Archivo eliminado exitosamente: " + path.toAbsolutePath());

        } catch (Exception e) {
            throw new Exception("No se pudo eliminar archivo " + filePath + ": " + e.getMessage(), e);
        }
    }
    
    private void executeReadFile(String filePath, int actionNumber) throws Exception {
        Path path = Paths.get(projectRoot.getAbsolutePath(), filePath);

        try {
            if (!Files.exists(path)) {
                addLog("❌ [" + actionNumber + "] Ruta no encontrada: " + filePath);
                return;
            }

            if (Files.isDirectory(path)) {
                addLog("✅ [" + actionNumber + "] Directorio leído: " + filePath);
                addLog("📂 Contenido (" + filePath + "):");
                addLog("─".repeat(50));
                
                File[] files = path.toFile().listFiles();
                if (files != null) {
                    for (File file : files) {
                        if (file.isDirectory()) {
                            addLog("  📁 " + file.getName() + "/");
                        } else {
                            long sizeKB = file.length() / 1024;
                            addLog("  📄 " + file.getName() + " (" + sizeKB + " KB)");
                        }
                    }
                } else {
                    addLog("  (vacío)");
                }
                
                addLog("─".repeat(50));
                LOGGER.info("Directorio leído: " + path.toAbsolutePath());
                return;
            }

            if (Files.isRegularFile(path)) {
                String content = Files.readString(path, StandardCharsets.UTF_8);

                addLog("✅ [" + actionNumber + "] Archivo leído: " + filePath);
                addLog("📄 Contenido (" + content.length() + " caracteres):");
                addLog("─".repeat(50));
                addLog(content);
                addLog("─".repeat(50));
                
                LOGGER.info("Archivo leído exitosamente: " + path.toAbsolutePath());
                return;
            }

            addLog("❌ [" + actionNumber + "] La ruta no es un archivo ni directorio: " + filePath);

        } catch (Exception e) {
            throw new Exception("No se pudo leer " + filePath + ": " + e.getMessage(), e);
        }
    }

    private String normalizeAndValidatePath(String filePath) throws IllegalArgumentException {
        if (filePath == null || filePath.trim().isEmpty()) {
            throw new IllegalArgumentException("La ruta no puede estar vacía");
        }

        filePath = filePath.trim();

        if (filePath.startsWith("/") || filePath.startsWith("\\") ||
            filePath.startsWith("~") || filePath.contains("..")) {
            throw new IllegalArgumentException("Ruta inválida (seguridad): " + filePath);
        }

        filePath = filePath.replace("\\", "/");

        try {
            Path projectPath = projectRoot.toPath().toRealPath();
            Path targetPath = projectPath.resolve(filePath).toRealPath();

            if (!targetPath.startsWith(projectPath)) {
                throw new IllegalArgumentException("Ruta fuera del proyecto: " + filePath);
            }
        } catch (Exception e) {
            LOGGER.fine("No se pudo validar ruta real, continuando: " + filePath);
        }

        return filePath;
    }

    private void addLog(String message) {
        if (message == null) {
            message = "(vacío)";
        }
        executionLog.add(message);
        LOGGER.info(message);
    }

    public List<String> getExecutionLog() {
        return new ArrayList<>(executionLog);
    }

    public PomXmlReader getPomReader() {
        return pomReader;
    }
}