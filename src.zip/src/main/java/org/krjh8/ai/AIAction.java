package org.krjh8.ai;

public class AIAction {
    public String type;
    public String path;
    public String content;

    public AIAction() {}

    public AIAction(String type, String path, String content) {
        this.type = type;
        this.path = path;
        this.content = content;
    }

    @Override
    public String toString() {
        return String.format("AIAction{type='%s', path='%s', content_length=%d}",
                type, path, content != null ? content.length() : 0);
    }

    public boolean isValid() {
        if (type == null || type.trim().isEmpty()) {
            return false;
        }

        if (path == null || path.trim().isEmpty()) {
            return false;
        }

        String normalizedType = type.toLowerCase().trim();

        if (normalizedType.equals("delete_file") || normalizedType.equals("read_file")) {
            return true;
        }

        if (normalizedType.equals("create_file") || normalizedType.equals("modify_file")) {
            return content != null && !content.trim().isEmpty();
        }

        return false;
    }
}