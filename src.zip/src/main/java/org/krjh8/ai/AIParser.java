package org.krjh8.ai;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AIParser {
    private static final Logger LOGGER = Logger.getLogger(AIParser.class.getName());
    private Gson gson;

    public AIParser() {
        this.gson = new Gson();
    }

    public List<AIAction> parseActions(String jsonResponse) {
        List<AIAction> actions = new ArrayList<>();

        try {
            jsonResponse = jsonResponse.trim();

            if (jsonResponse.contains("```json")) {
                jsonResponse = jsonResponse.substring(
                        jsonResponse.indexOf("```json") + 7,
                        jsonResponse.lastIndexOf("```")
                );
            } else if (jsonResponse.contains("```")) {
                jsonResponse = jsonResponse.substring(
                        jsonResponse.indexOf("```") + 3,
                        jsonResponse.lastIndexOf("```")
                );
            }

            jsonResponse = jsonResponse.trim();

            JsonObject root = gson.fromJson(jsonResponse, JsonObject.class);

            if (root == null) {
                LOGGER.warning("JSON root es null");
                return actions;
            }

            JsonArray actionsArray = root.getAsJsonArray("actions");

            if (actionsArray == null) {
                LOGGER.warning("No hay array 'actions' en la respuesta");
                return actions;
            }

            for (int i = 0; i < actionsArray.size(); i++) {
                try {
                    JsonObject actionJson = actionsArray.get(i).getAsJsonObject();
                    AIAction action = new AIAction();
                    action.type = getString(actionJson, "type");
                    action.path = getString(actionJson, "path");
                    action.content = getString(actionJson, "content");

                    if (action.isValid()) {
                        actions.add(action);
                        LOGGER.fine("Acción parseada: " + action);
                    } else {
                        LOGGER.warning("Acción inválida: " + actionJson);
                        LOGGER.warning("  - type: " + action.type);
                        LOGGER.warning("  - path: " + action.path);
                        LOGGER.warning("  - content length: " + 
                            (action.content != null ? action.content.length() : "null"));
                    }
                } catch (Exception e) {
                    LOGGER.log(Level.WARNING, "Error parseando acción #" + i, e);
                }
            }

            LOGGER.info("Parseadas " + actions.size() + " acciones de " + actionsArray.size());

        } catch (com.google.gson.JsonSyntaxException e) {
            LOGGER.log(Level.SEVERE, "Error de sintaxis JSON: " + e.getMessage(), e);
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error parseando respuesta JSON", e);
        }

        return actions;
    }

    private String getString(JsonObject obj, String key) {
        if (obj.has(key) && !obj.get(key).isJsonNull()) {
            return obj.get(key).getAsString();
        }
        return null;
    }
}