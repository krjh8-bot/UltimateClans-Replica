package org.krjh8.editor;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.logging.Logger;

public class UsageSearcher {
    private static final Logger LOGGER = Logger.getLogger(UsageSearcher.class.getName());
    private static final Set<String> IGNORED_FOLDERS = Set.of("target", "build", ".git", "node_modules", ".idea", ".settings", "bin", ".mvn");

    public static class UsageResult {
        private final File file;
        private final int lineNumber;
        private final String lineText;
        private final String matchedWord;

        public UsageResult(File file, int lineNumber, String lineText, String matchedWord) {
            this.file = file; this.lineNumber = lineNumber; this.lineText = lineText.trim(); this.matchedWord = matchedWord;
        }
        public File getFile() { return file; }
        public int getLineNumber() { return lineNumber; }
        public String getLineText() { return lineText; }
        public String getRelativePath(File root) { return root.toPath().relativize(file.toPath()).toString(); }
    }

    public static List<UsageResult> findUsages(File projectRoot, String word) {
        List<UsageResult> results = new ArrayList<>();
        if (word == null || word.trim().isEmpty() || word.length() < 2) return results;

        // Expresión regular para buscar la palabra completa (\b = word boundary)
        String regex = "\\b" + Pattern.quote(word.trim()) + "\\b";
        Pattern pattern = Pattern.compile(regex);

        List<File> javaFiles = findJavaFiles(projectRoot);
        
        for (File file : javaFiles) {
            try {
                List<String> lines = Files.readAllLines(file.toPath());
                for (int i = 0; i < lines.size(); i++) {
                    Matcher matcher = pattern.matcher(lines.get(i));
                    if (matcher.find()) {
                        results.add(new UsageResult(file, i + 1, lines.get(i), word.trim()));
                    }
                }
            } catch (IOException e) {
                LOGGER.warning("Error leyendo " + file.getName() + ": " + e.getMessage());
            }
        }
        return results;
    }

    private static List<File> findJavaFiles(File directory) {
        List<File> files = new ArrayList<>();
        findJavaFilesRecursive(directory, files);
        return files;
    }

    private static void findJavaFilesRecursive(File directory, List<File> files) {
        File[] children = directory.listFiles();
        if (children == null) return;
        for (File child : children) {
            if (child.isDirectory()) {
                if (!IGNORED_FOLDERS.contains(child.getName())) findJavaFilesRecursive(child, files);
            } else if (child.getName().endsWith(".java")) {
                files.add(child);
            }
        }
    }
}