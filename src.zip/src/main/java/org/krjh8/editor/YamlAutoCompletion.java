package org.krjh8.editor;

import java.util.ArrayList;
import java.util.List;

public class YamlAutoCompletion {
    

    private static final String[] YAML_KEYWORDS = {
        "true", "false", "null",
        "yes", "no", "on", "off"
    };
    
    private static final String[] YAML_STRUCTURES = {
        "  - ",
        "  key: ",
        "name: ",
        "version: ",
        "description: ",
        "author: ",
        "license: ",
        "dependencies: ",
        "  - item",
        "enabled: true",
        "disabled: false"
    };

    public static List<String> getSuggestions(String prefix) {
        List<String> suggestions = new ArrayList<>();
        String lowerPrefix = prefix.toLowerCase();
        
        for (String keyword : YAML_KEYWORDS) {
            if (keyword.startsWith(lowerPrefix)) {
                suggestions.add(keyword);
            }
        }
        
        for (String structure : YAML_STRUCTURES) {
            if (structure.toLowerCase().startsWith(lowerPrefix)) {
                suggestions.add(structure);
            }
        }
        
        return suggestions;
    }

    public static String getNextLineHint(String currentLine) {
        String trimmed = currentLine.trim();
        int indent = getIndentation(currentLine);
        
        if (trimmed.endsWith(":")) {
            return getIndentationString(indent + 2) + "key: value";
        }
        
        if (trimmed.startsWith("-")) {
            return getIndentationString(indent) + "- ";
        }
        
        if (!trimmed.contains(":")) {
            return getIndentationString(indent) + "key: value";
        }
        
        return getIndentationString(indent) + "# ";
    }

    private static int getIndentation(String line) {
        int count = 0;
        for (char c : line.toCharArray()) {
            if (c == ' ') {
                count++;
            } else if (c == '\t') {
                count += 2;
            } else {
                break;
            }
        }
        return count;
    }
    
    private static String getIndentationString(int spaces) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < spaces; i++) {
            sb.append(" ");
        }
        return sb.toString();
    }
}