package org.krjh8.editor;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class YamlValidator {
    
    public static class YamlError {
        public int line;
        public int column;
        public String message;
        public String type;
        
        public YamlError(int line, int column, String message, String type) {
            this.line = line;
            this.column = column;
            this.message = message;
            this.type = type;
        }
        
        @Override
        public String toString() {
            return String.format("Línea %d:%d - %s: %s", 
                line, column, type.toUpperCase(), message);
        }
    }

    public static List<YamlError> validate(String content) {
        List<YamlError> errors = new ArrayList<>();
        String[] lines = content.split("\n");
        
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            int lineNumber = i + 1;
            
            if (line.trim().isEmpty() || line.trim().startsWith("#")) {
                continue;
            }
            
            int indent = getIndentation(line);
            
            if (indent % 2 != 0) {
                errors.add(new YamlError(lineNumber, indent + 1,
                    "Indentación debe ser múltiplo de 2", "warning"));
            }
            
            String trimmed = line.trim();
            
            if (trimmed.contains(":")) {
                if (!isValidKeyValue(trimmed)) {
                    int colonIndex = line.indexOf(":");
                    errors.add(new YamlError(lineNumber, colonIndex + 1,
                        "Formato de clave-valor inválido", "error"));
                }
                
                int colonPos = line.indexOf(":");
                if (colonPos < line.length() - 1) {
                    char nextChar = line.charAt(colonPos + 1);
                    if (nextChar != ' ' && nextChar != '\n' && !trimmed.endsWith(":")) {
                        errors.add(new YamlError(lineNumber, colonPos + 2,
                            "Debe haber un espacio después de ':'", "error"));
                    }
                }
            }
            
            int errorCol = checkQuotes(line);
            if (errorCol >= 0) {
                errors.add(new YamlError(lineNumber, errorCol,
                    "Comillas desbalanceadas", "error"));
            }
            
            if (trimmed.startsWith("-")) {
                if (trimmed.length() > 1 && trimmed.charAt(1) != ' ') {
                    errors.add(new YamlError(lineNumber, 2,
                        "Debe haber un espacio después de '-'", "error"));
                }
            }
            
            errorCol = checkBrackets(line);
            if (errorCol >= 0) {
                errors.add(new YamlError(lineNumber, errorCol,
                    "Paréntesis, corchetes o llaves desbalanceados", "error"));
            }
        }
        
        return errors;
    }
    
    private static int getIndentation(String line) {
        int count = 0;
        for (char c : line.toCharArray()) {
            if (c == ' ') {
                count++;
            } else if (c == '\t') {
                count += 2;
            } else {
                break;
            }
        }
        return count;
    }

    private static boolean isValidKeyValue(String line) {
        Pattern pattern = Pattern.compile("^[a-zA-Z0-9_-]+\\s*:\\s*.*$");
        return pattern.matcher(line).matches();
    }

    private static int checkQuotes(String line) {
        int singleQuotes = 0;
        int doubleQuotes = 0;
        boolean inSingleQuote = false;
        boolean inDoubleQuote = false;
        
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            
            if (c == '\'' && !inDoubleQuote) {
                inSingleQuote = !inSingleQuote;
                singleQuotes++;
            } else if (c == '"' && !inSingleQuote) {
                inDoubleQuote = !inDoubleQuote;
                doubleQuotes++;
            }
        }
        
        if (singleQuotes % 2 != 0 || doubleQuotes % 2 != 0) {
            return line.length();
        }
        
        return -1;
    }

    private static int checkBrackets(String line) {
        int parens = 0;
        int brackets = 0;
        int braces = 0;
        
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            
            switch (c) {
                case '(':
                    parens++;
                    break;
                case ')':
                    parens--;
                    if (parens < 0) return i;
                    break;
                case '[':
                    brackets++;
                    break;
                case ']':
                    brackets--;
                    if (brackets < 0) return i;
                    break;
                case '{':
                    braces++;
                    break;
                case '}':
                    braces--;
                    if (braces < 0) return i;
                    break;
            }
        }
        
        if (parens != 0 || brackets != 0 || braces != 0) {
            return line.length();
        }
        
        return -1;
    }
}