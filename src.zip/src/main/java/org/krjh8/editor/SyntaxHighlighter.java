package org.krjh8.editor;

import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
import org.fife.ui.rsyntaxtextarea.SyntaxConstants;
import org.fife.ui.rtextarea.RTextScrollPane;

import javax.swing.*;

public class SyntaxHighlighter {

    public static RSyntaxTextArea createJavaEditor() {
        RSyntaxTextArea textArea = new RSyntaxTextArea(25, 80);
        textArea.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_JAVA);
        textArea.setCodeFoldingEnabled(true);
        textArea.setMarkOccurrences(true);
        textArea.setAutoIndentEnabled(true);
        textArea.setFont(new javax.swing.plaf.FontUIResource(
            "Consolas", javax.swing.JLabel.CENTER, 12
        ));
        
        return textArea;
    }

    public static RTextScrollPane createScrollPane(RSyntaxTextArea textArea) {
        RTextScrollPane scrollPane = new RTextScrollPane(textArea);
        scrollPane.setLineNumbersEnabled(true);
        scrollPane.setFoldIndicatorEnabled(true);
        return scrollPane;
    }

    public static void setDarkTheme(RSyntaxTextArea textArea) {
        textArea.setBackground(new java.awt.Color(30, 30, 30));
        textArea.setForeground(new java.awt.Color(220, 220, 220));
        textArea.setCaretColor(new java.awt.Color(200, 200, 200));
        textArea.setSelectionColor(new java.awt.Color(80, 80, 120));
        textArea.setCurrentLineHighlightColor(new java.awt.Color(50, 50, 50));
    }

    public static String getSyntaxStyleByExtension(String fileName) {
        String lowerName = fileName.toLowerCase();
        
        if (lowerName.endsWith(".java")) {
            return SyntaxConstants.SYNTAX_STYLE_JAVA;
        } else if (lowerName.endsWith(".xml") || lowerName.endsWith(".pom")) {
            return SyntaxConstants.SYNTAX_STYLE_XML;
        } else if (lowerName.endsWith(".properties")) {
            return SyntaxConstants.SYNTAX_STYLE_PROPERTIES_FILE;
        } else if (lowerName.endsWith(".json")) {
            return SyntaxConstants.SYNTAX_STYLE_JSON;
        } else if (lowerName.endsWith(".sql")) {
            return SyntaxConstants.SYNTAX_STYLE_SQL;
        } else if (lowerName.endsWith(".html") || lowerName.endsWith(".htm")) {
            return SyntaxConstants.SYNTAX_STYLE_HTML;
        } else if (lowerName.endsWith(".js")) {
            return SyntaxConstants.SYNTAX_STYLE_JAVASCRIPT;
        } else if (lowerName.endsWith(".css")) {
            return SyntaxConstants.SYNTAX_STYLE_CSS;
        } else if (lowerName.endsWith(".py")) {
            return SyntaxConstants.SYNTAX_STYLE_PYTHON;
        } else if (lowerName.endsWith(".cpp") || lowerName.endsWith(".c") || lowerName.endsWith(".h")) {
            return SyntaxConstants.SYNTAX_STYLE_CPLUSPLUS;
        } else {
            return SyntaxConstants.SYNTAX_STYLE_NONE;
        }
    }
}